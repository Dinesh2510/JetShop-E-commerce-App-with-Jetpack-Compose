<?php
include 'config.php';

header('Content-Type: application/json');

if (!isset($_POST['address_id'], $_POST['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$address_id = trim($_POST['address_id']);
$user_id = trim($_POST['user_id']);
$address = isset($_POST['address']) ? trim($_POST['address']) : null;
$city = isset($_POST['city']) ? trim($_POST['city']) : null;
$state = isset($_POST['state']) ? trim($_POST['state']) : null;
$zip_code = isset($_POST['zip_code']) ? trim($_POST['zip_code']) : null;
$country = isset($_POST['country']) ? trim($_POST['country']) : null;
$latitude = isset($_POST['latitude']) ? trim($_POST['latitude']) : null;
$longitude = isset($_POST['longitude']) ? trim($_POST['longitude']) : null;
$type = isset($_POST['type']) ? trim($_POST['type']) : null;

$query = "UPDATE user_addresses SET ";
$params = [];
$types = "";

if ($address) { $query .= "address = ?, "; $params[] = $address; $types .= "s"; }
if ($city) { $query .= "city = ?, "; $params[] = $city; $types .= "s"; }
if ($state) { $query .= "state = ?, "; $params[] = $state; $types .= "s"; }
if ($zip_code) { $query .= "zip_code = ?, "; $params[] = $zip_code; $types .= "s"; }
if ($country) { $query .= "country = ?, "; $params[] = $country; $types .= "s"; }
if ($latitude) { $query .= "latitude = ?, "; $params[] = $latitude; $types .= "d"; }
if ($longitude) { $query .= "longitude = ?, "; $params[] = $longitude; $types .= "d"; }
if ($type && in_array($type, ['Home', 'Office'])) { $query .= "type = ?, "; $params[] = $type; $types .= "s"; }

$query = rtrim($query, ", ") . " WHERE id = ? AND user_id = ?";
$params[] = $address_id;
$params[] = $user_id;
$types .= "ii";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Address updated successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update address."]);
}
$stmt->close();
?>
