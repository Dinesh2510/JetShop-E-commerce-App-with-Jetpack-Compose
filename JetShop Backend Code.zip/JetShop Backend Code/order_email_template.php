<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Poppins', sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
    <table align="center" width="100%" bgcolor="#f4f4f4" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center">
                <table width="600px" bgcolor="#ffffff" cellpadding="0" cellspacing="0" style="margin-top: 20px; border-radius: 8px; overflow: hidden;">
                    <tr>
                        <td align="left" style="padding: 20px; font-size: 16px;">
                            <p><b>Hi,</b></p>
                            <p>Your order is confirmed! Below are the details.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 20px;">
                            <table width="100%" bgcolor="#e8f5e9" cellpadding="12" cellspacing="0" style="border-radius: 8px;">
                                <tr><td>Order ID</td><td align="right"><?php echo $order['order_id']; ?></td></tr>
                                <tr><td>Order Date</td><td align="right"><?php echo date("d M Y", strtotime($order['created_at'])); ?></td></tr>
                                <tr><td>Status</td><td align="right"><b><?php echo strtoupper($order['status']); ?></b></td></tr>
                                <tr><td>Subtotal</td><td align="right"><?php echo formatCurrency($order['subtotal']); ?></td></tr>
                                <tr><td>Total</td><td align="right"><b><?php echo formatCurrency($order['total_amount']); ?></b></td></tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="padding-bottom: 30px;">
                            <a href="https://yourwebsite.com/orders/<?php echo $order['order_id']; ?>" style="background-color: #007c4d; color: #ffffff; padding: 14px 24px; font-size: 16px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: 600;">
                                VIEW ORDER
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
