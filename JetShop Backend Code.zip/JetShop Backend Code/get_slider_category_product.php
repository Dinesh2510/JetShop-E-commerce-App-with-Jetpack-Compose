<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");
require_once "config.php";  // Ensure this sets up $conn

// Set charset to UTF-8 to avoid malformed UTF-8 characters
//$conn->set_charset('utf8');
$conn->set_charset("utf8mb4");

$response = [];
$sections = [];
$icon_base_url = "https://pixeldev.in/webservices/e_commerce/admin/";

// Get user_id from request (can be null)
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// --- Get all sections ---
$sectionQuery = "SELECT section_id, section_name FROM sections";
$sectionResult = $conn->query($sectionQuery);
if (!$sectionResult) {
    echo json_encode(["status" => "error", "message" => "Section Query Error: " . $conn->error]);
    exit;
}

while ($sectionRow = $sectionResult->fetch_assoc()) {
    $section_id = $sectionRow["section_id"];
    $section_name = $sectionRow["section_name"];

    // --- Fetch Products for each Section ---
    $productQuery = "SELECT 
                        p.product_id, 
                        p.product_name, 
                        p.product_description, 
                        p.product_price, 
                        p.product_discount_price,
                        p.product_stock_quantity,
                        p.product_category_id,
                        p.product_brand_id,
                        p.product_weight,
                        p.product_dimensions,
                        p.product_color,
                        p.product_size,
                        p.product_rating,
                        p.product_total_reviews,
                        p.product_image_url,
                        p.product_thumbnail_url,
                        p.product_is_featured,
                        p.product_is_active,
                        p.product_created_at,
                        p.product_updated_at,
                        COALESCE(c.quantity, 0) AS user_cart_quantity
                     FROM products p
                     JOIN product_sections sp ON p.product_id = sp.product_id
                     LEFT JOIN cart c ON p.product_id = c.product_id 
                     AND (c.user_id = ? OR ? IS NULL)  -- Handles user_id NULL case
                     WHERE sp.section_id = ?";
                     
    $productStmt = $conn->prepare($productQuery);
    if (!$productStmt) {
        echo json_encode(["status" => "error", "message" => "Prepare Error: " . $conn->error]);
        exit;
    }

    $productStmt->bind_param("sss", $user_id, $user_id, $section_id);
    
    if (!$productStmt->execute()) {
        echo json_encode(["status" => "error", "message" => "Execute Error: " . $productStmt->error]);
        exit;
    }
    
    $productResult = $productStmt->get_result();
    $products = [];
    
    if ($productResult && $productResult->num_rows > 0) {
        while ($productRow = $productResult->fetch_assoc()) {
            $products[] = $productRow;
        }
    }

    $sections[] = [
        "section_id"   => $section_id,
        "section_name" => $section_name,
        "products"     => $products
    ];
}

// --- Get active slider images ---
$sliderQuery = "SELECT slider_id, image_url, redirect_url, title, description FROM slider_images WHERE is_active = 1 ORDER BY created_at DESC";
$sliderResult = $conn->query($sliderQuery);
if (!$sliderResult) {
    echo json_encode(["status" => "error", "message" => "Slider Query Error: " . $conn->error]);
    exit;
}
$sliders = [];
while ($row = $sliderResult->fetch_assoc()) {
    $sliders[] = $row;
}

// --- Get active categories ---
$categoriesQuery = "SELECT id, name, CONCAT('$icon_base_url', icon) AS icon, draft, brief, priority, created_at 
                    FROM productCategories 
                    WHERE disable_flag = 0 
                    ORDER BY priority ASC";
$resultCategory = mysqli_query($conn, $categoriesQuery);
if (!$resultCategory) {
    echo json_encode(["status" => "error", "message" => "Categories Query Error: " . mysqli_error($conn)]);
    exit;
}
$categories = [];
while ($row = mysqli_fetch_assoc($resultCategory)) {
    $categories[] = $row;
}

// --- Get all active brands ---
$brandsQuery = "SELECT brand_id, brand_name, brand_logo, brand_description, website_url, status, created_at, updated_at 
                FROM brands 
                WHERE status = 1 
                ORDER BY brand_name ASC";
$resultBrands = mysqli_query($conn, $brandsQuery);
if (!$resultBrands) {
    echo json_encode(["status" => "error", "message" => "Brands Query Error: " . mysqli_error($conn)]);
    exit;
}
$brandsList = [];
while ($row = mysqli_fetch_assoc($resultBrands)) {
    $brandsList[] = $row;
}

$response = [
    "status"        => "success",
    "sections"      => $sections,
    "slider_images" => $sliders,
    "categories"    => $categories,
    "brands"        => $brandsList
];

$json = json_encode($response, JSON_PRETTY_PRINT);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["status" => "error", "message" => "JSON Encode Error: " . json_last_error_msg()]);
    exit;
}

echo $json;
$conn->close();
?>
