<?php
// export_csv.php
require_once('db_config.php');

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=products_export.csv');

$output = fopen("php://output", "w");

// Column headings
fputcsv($output, array('product_id','product_name','product_description','product_price','product_discount_price','product_stock_quantity','product_category_id','product_brand_id','product_weight','product_dimensions','product_color','product_size','product_rating','product_total_reviews','product_image_url','product_thumbnail_url','product_is_featured','product_is_active','product_created_at','product_updated_at'));

$sql = "SELECT * FROM products ORDER BY product_created_at DESC";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()){
    fputcsv($output, $row);
}
fclose($output);
exit;
?>
