<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import CSV File</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .container { max-width: 500px; margin: auto; text-align: center; }
        .progress { width: 100%; background: #ccc; height: 25px; border-radius: 5px; overflow: hidden; }
        .progress-bar { width: 0%; height: 100%; background: green; text-align: center; color: white; }
        .message { margin-top: 10px; padding: 10px; display: none; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>

<div class="container">
    <h2>Upload CSV File</h2>
    <form id="uploadForm" action="process_csv.php" method="post" enctype="multipart/form-data">
        <input type="file" name="csv_file" required>
        <br><br>
        <button type="submit">Upload & Import</button>
    </form>

    <div class="progress" id="progressContainer" style="display: none;">
        <div class="progress-bar" id="progressBar">0%</div>
    </div>

    <div id="message" class="message"></div>
</div>

<script>
    document.getElementById("uploadForm").onsubmit = function() {
        document.getElementById("progressContainer").style.display = "block";
        let progressBar = document.getElementById("progressBar");
        let width = 0;
        let interval = setInterval(() => {
            if (width >= 100) {
                clearInterval(interval);
            } else {
                width += 5;
                progressBar.style.width = width + "%";
                progressBar.innerHTML = width + "%";
            }
        }, 200);
    };
</script>

</body>
</html>
