
<?php
$servername = "localhost"; // Change if needed
$username = "hyqgektr_jetshop"; // Change to your database user
$password = "StqSZ6L47cVqdUCTazj7"; // Change to your database password
$dbname = "hyqgektr_jetshop"; // Change to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}
?>
