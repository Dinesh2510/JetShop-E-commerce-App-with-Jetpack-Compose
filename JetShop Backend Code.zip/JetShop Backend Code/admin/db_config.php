
<?php
$servername = "localhost"; // Change if needed
$username = ""; // Change to your database user
$password = ""; // Change to your database password
$dbname = ""; // Change to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}
?>
