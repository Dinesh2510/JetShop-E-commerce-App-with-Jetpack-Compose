<?php
require_once('db_config.php');

// Fetch categories for dropdown
$categories = $conn->query("SELECT id, name FROM productCategories ORDER BY name ASC");

// Fetch brands for dropdown
$brands = $conn->query("SELECT brand_id, brand_name FROM brands ORDER BY brand_name ASC");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $product_description = $_POST['product_description'];
    $product_price = $_POST['product_price'];
    $product_discount_price = $_POST['product_discount_price'];
    $product_stock_quantity = $_POST['product_stock_quantity'];
    $product_category_id = $_POST['product_category_id'];
    $product_brand_id = $_POST['product_brand_id'];
    $product_weight = $_POST['product_weight'];
    $product_dimensions = $_POST['product_dimensions'];
    $product_color = $_POST['product_color']; // HEX Color
    $product_size = $_POST['product_size'];
    $product_rating = $_POST['product_rating'];
    $product_total_reviews = $_POST['product_total_reviews'];
    $product_is_featured = isset($_POST['product_is_featured']) ? 1 : 0;
    $product_is_active = isset($_POST['product_is_active']) ? 1 : 0;

    // File Upload
    $upload_dir = "uploads/";
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $product_image_url = null;
    if (isset($_FILES['product_image_url']) && $_FILES['product_image_url']['error'] == 0) {
        $img_ext = pathinfo($_FILES['product_image_url']['name'], PATHINFO_EXTENSION);
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array(strtolower($img_ext), $allowed_types)) {
            $img_name = time() . "_" . uniqid() . "." . $img_ext;
            $target_path = $upload_dir . $img_name;
            if (move_uploaded_file($_FILES['product_image_url']['tmp_name'], $target_path)) {
                $product_image_url = $target_path;
            } else {
                $error = "Failed to upload product image.";
            }
        } else {
            $error = "Invalid image format. Allowed formats: JPG, PNG, GIF.";
        }
    }

    $product_thumbnail_url = null;
    if (isset($_FILES['product_thumbnail_url']) && $_FILES['product_thumbnail_url']['error'] == 0) {
        $thumb_ext = pathinfo($_FILES['product_thumbnail_url']['name'], PATHINFO_EXTENSION);
        if (in_array(strtolower($thumb_ext), $allowed_types)) {
            $thumb_name = time() . "_" . uniqid() . "." . $thumb_ext;
            $target_thumb_path = $upload_dir . $thumb_name;
            if (move_uploaded_file($_FILES['product_thumbnail_url']['tmp_name'], $target_thumb_path)) {
                $product_thumbnail_url = $target_thumb_path;
            } else {
                $error = "Failed to upload product thumbnail.";
            }
        } else {
            $error = "Invalid thumbnail format.";
        }
    }

    if (!isset($error)) {
        // Use Prepared Statements to prevent SQL Injection
        $stmt = $conn->prepare("INSERT INTO products (product_name, product_description, product_price, product_discount_price, product_stock_quantity, product_category_id, product_brand_id, product_weight, product_dimensions, product_color, product_size, product_rating, product_total_reviews, product_image_url, product_thumbnail_url, product_is_featured, product_is_active, product_created_at, product_updated_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");

        $stmt->bind_param("ssddiiisssssddssi", $product_name, $product_description, $product_price, $product_discount_price, $product_stock_quantity, $product_category_id, $product_brand_id, $product_weight, $product_dimensions, $product_color, $product_size, $product_rating, $product_total_reviews, $product_image_url, $product_thumbnail_url, $product_is_featured, $product_is_active);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Database Error: " . $conn->error;
        }
    }
}
?>
