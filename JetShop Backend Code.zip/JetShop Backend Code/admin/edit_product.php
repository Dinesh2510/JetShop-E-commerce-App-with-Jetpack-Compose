<?php
// edit_product.php
require_once('db_config.php');

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$product_id = intval($_GET['id']);
$sql = "SELECT * FROM products WHERE product_id = $product_id";
$result = $conn->query($sql);
if($result->num_rows == 0){
    die("Product not found.");
}
$product = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $conn->real_escape_string($_POST['product_name']);
    $product_description = $conn->real_escape_string($_POST['product_description']);
    $product_price = $_POST['product_price'];
    $product_discount_price = $_POST['product_discount_price'];
    $product_stock_quantity = $_POST['product_stock_quantity'];
    $product_category_id = $_POST['product_category_id'];
    $product_brand_id = $_POST['product_brand_id'];
    $product_weight = $_POST['product_weight'];
    $product_dimensions = $conn->real_escape_string($_POST['product_dimensions']);
    $product_color = $conn->real_escape_string($_POST['product_color']);
    $product_size = $conn->real_escape_string($_POST['product_size']);
    $product_rating = $_POST['product_rating'];
    $product_total_reviews = $_POST['product_total_reviews'];
    $product_is_featured = isset($_POST['product_is_featured']) ? 1 : 0;
    $product_is_active = isset($_POST['product_is_active']) ? 1 : 0;
    
    $upload_dir = "uploads/";
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Update product image if a new one is uploaded
    if (isset($_FILES['product_image_url']) && $_FILES['product_image_url']['error'] == 0) {
        $img_name = time() . "_" . basename($_FILES['product_image_url']['name']);
        $target_path = $upload_dir . $img_name;
        if(move_uploaded_file($_FILES['product_image_url']['tmp_name'], $target_path)){
            $product_image_url = $target_path;
        }
    } else {
        $product_image_url = $product['product_image_url'];
    }
    
    // Update thumbnail if a new one is uploaded
    if (isset($_FILES['product_thumbnail_url']) && $_FILES['product_thumbnail_url']['error'] == 0) {
        $thumb_name = time() . "_" . basename($_FILES['product_thumbnail_url']['name']);
        $target_thumb_path = $upload_dir . $thumb_name;
        if(move_uploaded_file($_FILES['product_thumbnail_url']['tmp_name'], $target_thumb_path)){
            $product_thumbnail_url = $target_thumb_path;
        }
    } else {
        $product_thumbnail_url = $product['product_thumbnail_url'];
    }
    
    $sql = "UPDATE products SET 
              product_name = '$product_name',
              product_description = '$product_description',
              product_price = '$product_price',
              product_discount_price = '$product_discount_price',
              product_stock_quantity = '$product_stock_quantity',
              product_category_id = '$product_category_id',
              product_brand_id = '$product_brand_id',
              product_weight = '$product_weight',
              product_dimensions = '$product_dimensions',
              product_color = '$product_color',
              product_size = '$product_size',
              product_rating = '$product_rating',
              product_total_reviews = '$product_total_reviews',
              product_image_url = '$product_image_url',
              product_thumbnail_url = '$product_thumbnail_url',
              product_is_featured = '$product_is_featured',
              product_is_active = '$product_is_active',
              product_updated_at = NOW()
            WHERE product_id = $product_id";
    
    if($conn->query($sql) === TRUE){
        header("Location: index.php");
        exit;
    } else {
        $error = "Error: " . $conn->error;
    }
    
    // Reload product info after update
    $sql = "SELECT * FROM products WHERE product_id = $product_id";
    $result = $conn->query($sql);
    $product = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Product</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h2>Edit Product</h2>
  <?php if(isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>
  <form method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label>Product Name</label>
      <input type="text" name="product_name" class="form-control" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>
    </div>
    <div class="form-group">
      <label>Description</label>
      <textarea name="product_description" class="form-control" required><?php echo htmlspecialchars($product['product_description']); ?></textarea>
    </div>
    <div class="form-group">
      <label>Price</label>
      <input type="number" step="0.01" name="product_price" class="form-control" value="<?php echo $product['product_price']; ?>" required>
    </div>
    <div class="form-group">
      <label>Discount Price</label>
      <input type="number" step="0.01" name="product_discount_price" class="form-control" value="<?php echo $product['product_discount_price']; ?>">
    </div>
    <div class="form-group">
      <label>Stock Quantity</label>
      <input type="number" name="product_stock_quantity" class="form-control" value="<?php echo $product['product_stock_quantity']; ?>" required>
    </div>
    <div class="form-group">
      <label>Category ID</label>
      <input type="number" name="product_category_id" class="form-control" value="<?php echo $product['product_category_id']; ?>" required>
    </div>
    <div class="form-group">
      <label>Brand ID</label>
      <input type="number" name="product_brand_id" class="form-control" value="<?php echo $product['product_brand_id']; ?>" required>
    </div>
    <div class="form-group">
      <label>Weight</label>
      <input type="text" name="product_weight" class="form-control" value="<?php echo $product['product_weight']; ?>">
    </div>
    <div class="form-group">
      <label>Dimensions</label>
      <input type="text" name="product_dimensions" class="form-control" value="<?php echo htmlspecialchars($product['product_dimensions']); ?>">
    </div>
    <div class="form-group">
      <label>Color</label>
      <input type="text" name="product_color" class="form-control" value="<?php echo htmlspecialchars($product['product_color']); ?>">
    </div>
    <div class="form-group">
      <label>Size</label>
      <input type="text" name="product_size" class="form-control" value="<?php echo htmlspecialchars($product['product_size']); ?>">
    </div>
    <div class="form-group">
      <label>Rating</label>
      <input type="number" step="0.1" name="product_rating" class="form-control" value="<?php echo $product['product_rating']; ?>">
    </div>
    <div class="form-group">
      <label>Total Reviews</label>
      <input type="number" name="product_total_reviews" class="form-control" value="<?php echo $product['product_total_reviews']; ?>">
    </div>
    <div class="form-group">
      <label>Product Image</label>
      <?php if($product['product_image_url']) { ?>
        <div>
          <img src="<?php echo $product['product_image_url']; ?>" alt="Product Image" style="max-width:150px;">
        </div>
      <?php } ?>
      <input type="file" name="product_image_url" class="form-control-file">
    </div>
    <div class="form-group">
      <label>Thumbnail Image</label>
      <?php if($product['product_thumbnail_url']) { ?>
        <div>
          <img src="<?php echo $product['product_thumbnail_url']; ?>" alt="Thumbnail Image" style="max-width:150px;">
        </div>
      <?php } ?>
      <input type="file" name="product_thumbnail_url" class="form-control-file">
    </div>
    <div class="form-check">
      <input type="checkbox" name="product_is_featured" class="form-check-input" id="featured" <?php echo ($product['product_is_featured'] == 1) ? 'checked' : ''; ?>>
      <label class="form-check-label" for="featured">Featured</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="product_is_active" class="form-check-input" id="active" <?php echo ($product['product_is_active'] == 1) ? 'checked' : ''; ?>>
      <label class="form-check-label" for="active">Active</label>
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Update Product</button>
    <a href="index.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>
</body>
</html>
