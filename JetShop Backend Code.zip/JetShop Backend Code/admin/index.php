<?php
// index.php
require_once('db_config.php');

$sql = "SELECT * FROM products ORDER BY product_created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product Admin Panel</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h2>Products</h2>
  <div class="mb-3">
    <a href="add_product.php" class="btn btn-success">Add New Product</a>
    <a href="export_csv.php" class="btn btn-info">Export CSV</a>
    <a href="import_csv.php" class="btn btn-secondary">Import CSV</a>
  </div>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Discount Price</th>
        <th>Stock Qty</th>
        <th>Category ID</th>
        <th>Brand ID</th>
        <th>Weight</th>
        <th>Dimensions</th>
        <th>Color</th>
        <th>Size</th>
        <th>Rating</th>
        <th>Total Reviews</th>
        <th>Image URL</th>
        <th>Thumbnail URL</th>
        <th>Featured</th>
        <th>Active</th>
        <th>Created At</th>
        <th>Updated At</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()){ ?>
      <tr>
        <td><?php echo $row['product_id']; ?></td>
        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
        <td><?php echo htmlspecialchars($row['product_description']); ?></td>
        <td><?php echo $row['product_price']; ?></td>
        <td><?php echo $row['product_discount_price']; ?></td>
        <td><?php echo $row['product_stock_quantity']; ?></td>
        <td><?php echo $row['product_category_id']; ?></td>
        <td><?php echo $row['product_brand_id']; ?></td>
        <td><?php echo $row['product_weight']; ?></td>
        <td><?php echo $row['product_dimensions']; ?></td>
        <td><?php echo $row['product_color']; ?></td>
        <td><?php echo $row['product_size']; ?></td>
        <td><?php echo $row['product_rating']; ?></td>
        <td><?php echo $row['product_total_reviews']; ?></td>
        <td><a href="<?php echo $row['product_image_url']; ?>" target="_blank">View</a></td>
        <td><a href="<?php echo $row['product_thumbnail_url']; ?>" target="_blank">View</a></td>
        <td><?php echo ($row['product_is_featured'] == 1) ? 'Yes' : 'No'; ?></td>
        <td><?php echo ($row['product_is_active'] == 1) ? 'Active' : 'Inactive'; ?></td>
        <td><?php echo $row['product_created_at']; ?></td>
        <td><?php echo $row['product_updated_at']; ?></td>
        <td>
          <a href="edit_product.php?id=<?php echo $row['product_id']; ?>" class="btn btn-primary btn-sm">Edit</a>
          <a href="delete_product.php?id=<?php echo $row['product_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete product?');">Delete</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>
