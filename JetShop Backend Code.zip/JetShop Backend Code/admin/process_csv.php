<?php
require_once('db_config.php');


if (isset($_FILES["csv_file"])) {
    $fileName = $_FILES["csv_file"]["tmp_name"];
    if ($_FILES["csv_file"]["size"] > 0) {
        $file = fopen($fileName, "r");
        $rowCount = 0;
        
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
            if ($rowCount == 0) { $rowCount++; continue; } // Skip the first row (header)

            $stmt = $conn->prepare("INSERT INTO products (product_name, product_description, product_price, product_discount_price, product_stock_quantity, product_category_id, product_brand_id, product_weight, product_dimensions, product_color, product_size, product_rating, product_total_reviews, product_image_url, product_thumbnail_url, product_is_featured, product_is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $stmt->bind_param("sssddiidsssdissii",
                $column[0],  // product_name
                $column[1],  // product_description
                $column[2],  // product_price
                $column[3],  // product_discount_price
                $column[4],  // product_stock_quantity
                $column[5],  // product_category_id
                $column[6],  // product_brand_id
                $column[7],  // product_weight
                $column[8],  // product_dimensions
                $column[9],  // product_color
                $column[10], // product_size
                $column[11], // product_rating
                $column[12], // product_total_reviews
                $column[13], // product_image_url
                $column[14], // product_thumbnail_url
                $column[15], // product_is_featured
                $column[16]  // product_is_active
            );

            $stmt->execute();
            $rowCount++;
        }

        fclose($file);
        echo json_encode(["status" => "success", "message" => "$rowCount products imported successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid file size!"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "No file uploaded!"]);
}

$conn->close();
?>
