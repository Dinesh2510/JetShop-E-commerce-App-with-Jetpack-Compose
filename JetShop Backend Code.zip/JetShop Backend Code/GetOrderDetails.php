<?php
ob_start();
header("Content-Type: application/json; charset=UTF-8");
require_once "config.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

function handleError($errno, $errstr, $errfile, $errline) {
    echo json_encode(["status" => "error", "message" => "PHP Error: $errstr in $errfile on line $errline"]);
    exit();
}
set_error_handler("handleError");

if (!isset($_POST['user_id']) || empty(trim($_POST['user_id']))) {
    echo json_encode(["status" => "error", "message" => "Missing user_id", "coupon_applied" => 0]);
    exit();
}

$user_id = trim($_POST['user_id']);
$coupon_code = isset($_POST['coupon_code']) ? trim($_POST['coupon_code']) : null;

$cartQuery = "
    SELECT 
        c.cart_id, c.quantity,
        p.product_id, p.product_name, p.product_price, p.product_discount_price,
        p.product_stock_quantity, p.product_category_id, p.product_brand_id,
        p.product_weight, p.product_dimensions, p.product_color, p.product_size,
        p.product_rating, p.product_total_reviews, p.product_image_url,
        p.product_thumbnail_url, p.product_is_featured, p.product_is_active,
        p.product_created_at, p.product_updated_at
    FROM cart c
    JOIN products p ON c.product_id = p.product_id
    WHERE c.user_id = ?";

$cartStmt = $conn->prepare($cartQuery);
$cartStmt->bind_param("s", $user_id);
$cartStmt->execute();
$result = $cartStmt->get_result();

$cartItems = [];
$subtotal = 0;
$totalTax = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        array_walk_recursive($row, function (&$value) {
            if (!mb_detect_encoding($value, 'UTF-8', true)) {
                $value = utf8_encode($value);
            }
        });

        $itemPrice = !empty($row['product_discount_price']) ? $row['product_discount_price'] : $row['product_price'];
        $quantityAmountPrice = $itemPrice * $row['quantity'];
        $taxPerItem = $quantityAmountPrice * 0.18;
        $quantityAmountPriceWithTax = $quantityAmountPrice + $taxPerItem;

        $subtotal += $quantityAmountPrice;
        $totalTax += $taxPerItem;

        $row['quantity_amount_price'] = number_format($quantityAmountPrice, 2);
        $row['tax_amount'] = number_format($taxPerItem, 2);
        $row['quantity_amount_price_with_tax'] = number_format($quantityAmountPriceWithTax, 2);
        $cartItems[] = $row;
    }
} else {
    echo json_encode(["status" => "error", "message" => "No items in cart", "coupon_applied" => 0]);
    exit();
}

$addressQuery = "SELECT * FROM user_addresses WHERE user_id = ? AND default_address = 1 LIMIT 1";
$addressStmt = $conn->prepare($addressQuery);
$addressStmt->bind_param("s", $user_id);
$addressStmt->execute();
$addressResult = $addressStmt->get_result();
$shippingAddress = $addressResult->fetch_assoc() ?: null;

$discount = 0;
$couponApplied = 0;
$message = "Order details retrieved successfully";

if (!empty($coupon_code)) {
    $couponQuery = "SELECT * FROM coupons WHERE coupon_code = ? AND status = 'active' AND expiry_date > NOW() LIMIT 1";
    $couponStmt = $conn->prepare($couponQuery);
    $couponStmt->bind_param("s", $coupon_code);
    $couponStmt->execute();
    $couponResult = $couponStmt->get_result();

    if ($couponRow = $couponResult->fetch_assoc()) {
        if ($subtotal >= $couponRow['min_order_amount']) {
            if ($couponRow['used_count'] < $couponRow['usage_limit']) {
                if ($couponRow['discount_type'] == 'percentage') {
                    $discount = ($subtotal * $couponRow['discount_value']) / 100;
                    if (!empty($couponRow['max_discount']) && $discount > $couponRow['max_discount']) {
                        $discount = $couponRow['max_discount'];
                    }
                } else {
                    $discount = $couponRow['discount_value'];
                }

                $couponApplied = 1;
                $message = "Coupon applied successfully";
            } else {
                $message = "Coupon usage limit reached";
            }
        } else {
            $message = "Minimum order amount not met for this coupon";
        }
    } else {
        $message = "Invalid or expired coupon";
    }
}

//if order is more than 1000, delivery charge is free
//$deliveryCharge = ($subtotal < 1000) ? 99 : 0;
// ✅ Membership-based delivery charge
$deliveryCharge = 199; // default charge

$membershipQuery = "SELECT * FROM prime_membership WHERE user_id = ? AND transaction_status = 'success' AND expiry_date > NOW() LIMIT 1";
$membershipStmt = $conn->prepare($membershipQuery);
$membershipStmt->bind_param("s", $user_id);
$membershipStmt->execute();
$membershipResult = $membershipStmt->get_result();

if ($membershipResult->num_rows > 0) {
    $deliveryCharge = 0; // ✅ Free delivery for active members
}
$membershipStmt->close();

$finalTotal = $subtotal - $discount + $totalTax + $deliveryCharge;

echo json_encode([
    "status" => "success",
    "message" => $message,
    "coupon_applied" => $couponApplied,
    "Subtotal" => number_format($subtotal, 2),
    "Discount" => number_format($discount, 2),
    "Tax" => number_format($totalTax, 2),
    "Delivery Charges" => number_format($deliveryCharge, 2),
    "Final Total" => number_format($finalTotal, 2),
    "shippingAddress" => $shippingAddress,
    "cart_items" => $cartItems
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

$cartStmt->close();
$addressStmt->close();
$conn->close();
?>
