<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function sendOTP($email, $name, $otp) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // ✅ Replace with your SMTP server (e.g., smtp.gmail.com)
        $mail->SMTPAuth = true;
        $mail->Username = 'pixeldevteams@gmail.com'; // ✅ Replace with your email
        $mail->Password = 'eeil kegu yvqq yjha'; // ✅ Replace with your email password or App Password
        $mail->SMTPSecure = 'tls'; // Use `ssl` if required by your provider
        $mail->Port = 587; // Change if using `ssl` (465)

        $mail->setFrom('support@pixeldev.in', 'JetShop'); // ✅ Replace with your email
        $mail->addAddress($email); // ✅ Send OTP to user’s email
        
        $mail->isHTML(true);  // ✅ Enable HTML email
        $mail->Subject = 'Verify your email - JetShop';
// Load the email template
        $emailTemplate = file_get_contents('email_template.html');
        $emailTemplate = str_replace('{USERNAME}', $name, $emailTemplate);
        $emailTemplate = str_replace('{OTP_CODE}', $otp, $emailTemplate);
        $emailTemplate = str_replace('{YEAR}', date('Y'), $emailTemplate); // ✅ Add PHP-generated Year

        $mail->Body = $emailTemplate;
    //     // ✅ HTML Email Template
    //    $mail->Body = "
    //     <div style='max-width: 600px; margin: auto; font-family: Arial, sans-serif; border: 1px solid #ddd; border-radius: 8px; overflow: hidden;'>
    //         <!-- Header -->
    //         <div style='background: #007bff; color: white; padding: 15px; text-align: center;'>
    //             <img src='https://pixeldev.in/assets/img/logos.png' alt='Your App Logo' width='50' style='vertical-align: middle; margin-right: 10px;' />
    //             <span style='font-size: 22px; font-weight: bold;'>JetShop</span>
    //         </div>

    //         <!-- Body -->
    //         <div style='padding: 20px; text-align: center;'>
    //             <p style='font-size: 18px; color: #333;'>Hello <strong>$name</strong>,</p>
    //             <p style='font-size: 16px; color: #555;'>Use the following OTP to verify your email:</p>
    //             <p style='font-size: 24px; font-weight: bold; color: #007bff; border: 2px dashed #007bff; padding: 10px; display: inline-block;'>$otp</p>
    //             <p style='font-size: 14px; color: #777;'>This OTP is valid for 10 minutes. Do not share it with anyone.</p>
    //         </div>

    //         <!-- Footer -->
    //         <div style='background: #f1f1f1; color: #666; text-align: center; padding: 15px; font-size: 12px;'>
    //             &copy; " . date('Y') . " JetShop by PixelDev. All rights reserved.
    //         </div>
    //     </div>";

        if ($mail->send()) {
            return true;
        } else {
            error_log("OTP Email Error: " . $mail->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("OTP Email Exception: " . $e->getMessage());
        return false;
    }
}
?>
