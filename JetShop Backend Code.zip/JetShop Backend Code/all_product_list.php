<?php
include 'config.php'; // Database connection file

header('Content-Type: application/json');

// Get page number from request (default = 1)
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10; // Number of products per page
$offset = ($page - 1) * $limit; // Calculate offset

// Fetch total number of products (for pagination info)
$total_query = "SELECT COUNT(*) AS total FROM products WHERE product_is_active = 1";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_products = $total_row['total'];
$total_pages = ceil($total_products / $limit);

// Fetch paginated products
$query = "SELECT * FROM products WHERE product_is_active = 1 ORDER BY product_created_at DESC LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $products = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $products[] = $row;
    }

    echo json_encode([
        "success" => true,
        "message" => "Products fetched successfully.",
        "current_page" => $page,
        "total_pages" => $total_pages,
        "total_products" => $total_products,
        "products" => $products
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "No products found."
    ]);
}

mysqli_close($conn);
?>
