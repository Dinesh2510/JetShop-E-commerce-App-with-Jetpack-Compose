<?php
include 'config.php';
include 'send_thanks_mail.php'; // Include PHPMailer function

header('Content-Type: application/json');

if (!isset($_POST['email'], $_POST['otp'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$email = trim($_POST['email']);
$otp = trim($_POST['otp']);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "error", "message" => "Invalid email format."]);
    exit();
}

// ✅ Fetch user details
$stmt = $conn->prepare("SELECT first_name, last_name, otp, otp_expiry, is_verified FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Email not registered."]);
    $stmt->close();
    exit();
}

$stmt->bind_result($first_name, $last_name, $stored_otp, $otp_expiry, $is_verified);
$stmt->fetch();
$stmt->close(); // ✅ Closed after fetching data

$current_time = date("Y-m-d H:i:s");

if ($is_verified == 1) {
    echo json_encode(["status" => "error", "message" => "Email already verified."]);
    exit();
}

if ($stored_otp != $otp) {
    echo json_encode(["status" => "error", "message" => "Invalid OTP."]);
    exit();
}

if ($otp_expiry < $current_time) {
    echo json_encode(["status" => "error", "message" => "OTP has expired. Please request a new OTP."]);
    exit();
}

// ✅ Update verification status (Set `is_verified = 1` and remove OTP)
$stmt = $conn->prepare("UPDATE users SET is_verified = 1, otp = NULL, otp_expiry = NULL WHERE email = ?");
$stmt->bind_param("s", $email);

if ($stmt->execute()) {
    $stmt->close(); // ✅ Close only after execution
    // ✅ Send Thank You Email with first name and last name
    sendThankYouEmail($first_name . ' ' . $last_name, $email);  // Corrected string concatenation
    echo json_encode(["status" => "success", "message" => "OTP verified successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to verify OTP."]);
}
?>
