<?php
require_once "config.php";  // Database connection
include 'header.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);
header("Content-Type: application/json");

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    // Validate required fields
    if (!isset($data['user_id'], $data['cart_items'], $data['payment_method'], $data['shipping_address_id'])) {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
        exit;
    }

    // Database Connection Check
    if (!$conn) {
        echo json_encode(["status" => "error", "message" => "Database connection failed"]);
        exit;
    }

    // Assign values from request
    $user_id = intval($data['user_id']);
    $payment_method = $data['payment_method'];
    $shipping_address_id = intval($data['shipping_address_id']);
    $subtotal = floatval($data['Subtotal']);
    $discount = floatval($data['Discount']);
    $tax = floatval($data['Tax']);
    $delivery_charges = floatval($data['Delivery Charges']);
    $final_total = floatval($data['Final Total']);

    // Generate unique Order ID
    $order_id = "ORDER_" . strtoupper(substr(md5(uniqid()), 0, 8));

    // Fetch Shipping Address
    $sql = "SELECT * FROM user_addresses WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $shipping_address_id);
    $stmt->execute();
    $shipping_result = $stmt->get_result();

    if ($shipping_result->num_rows == 0) {
        echo json_encode(["status" => "error", "message" => "Invalid shipping address"]);
        exit;
    }
    $shipping_data = $shipping_result->fetch_assoc();

    // Set Transaction Status
    $transaction_status = ($payment_method == "COD") ? "N/A" : "Pending";

    // Insert Order
$sql = "INSERT INTO orders (order_id, user_id, subtotal, discount_value, coupon_code, tax_amount, delivery_charges, total_amount, status, payment_status, payment_method, transaction_status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Pending', ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("siddsddsss", $order_id, $user_id, $subtotal, $discount, $coupon_code, $tax, $delivery_charges, $final_total, $payment_method, $transaction_status);

    if (!$stmt->execute()) {
        echo json_encode(["status" => "error", "message" => "Failed to place order"]);
        exit;
    }

    // Insert Order Items
    foreach ($data['cart_items'] as $item) {
       $product_id = (string) $item['product_id'];  // Force it to be a string
        $quantity = intval($item['quantity']);
        $price = floatval($item['quantity_amount_price']);
        $tax_amount = floatval($item['tax_amount']);
        $total_price = floatval($item['quantity_amount_price_with_tax']);

        $sql = "INSERT INTO order_items (order_id, product_id, quantity, price, tax, total_price) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssiddd", $order_id, $product_id, $quantity, $price, $tax_amount, $total_price);
        if (!$stmt->execute()) {
            echo json_encode(["status" => "error", "message" => "Failed to insert order items"]);
            exit;
        }
    }
 // // var_dump($product_id, $quantity, $price, $tax_amount, $total_price);  // Debug the data being passed
    // // exit;  also u can try wihtout bind 
    // Insert Order Shipping Details
    $sql = "INSERT INTO order_shipping (order_id, user_id, address, google_address, latitude, longitude, city, state, postal_code, country, phone) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sissddsssss",
        $order_id, $user_id, 
        $shipping_data['address'], $shipping_data['google_address'], 
        $shipping_data['latitude'], $shipping_data['longitude'], 
        $shipping_data['city'], $shipping_data['state'], 
        $shipping_data['zip_code'], $shipping_data['country'], 
        $shipping_data['phone']
    );
    if (!$stmt->execute()) {
        echo json_encode(["status" => "error", "message" => "Failed to insert shipping details"]);
        exit;
    }

    // Handle Online Payment
    if ($payment_method != "COD") {
        if (!isset($data['payment_id'])) {
            echo json_encode(["status" => "error", "message" => "Missing payment ID for online payment"]);
            exit;
        }

        $payment_id = $data['payment_id']; // Razorpay/Paytm Payment ID
        $amount = $final_total;
        $currency = "INR";
        
        $sql = "INSERT INTO order_payments (payment_id, order_id, user_id, payment_method, amount, currency, transaction_status) 
                VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssisss", $payment_id, $order_id, $user_id, $payment_method, $amount, $currency);
        if (!$stmt->execute()) {
            echo json_encode(["status" => "error", "message" => "Failed to store payment details"]);
            exit;
        }
    }

    // Response
    $response = [
        "status" => "success",
        "message" => "Order placed successfully",
        "order_id" => $order_id,
        "Subtotal" => number_format($subtotal, 2),
        "Discount" => number_format($discount, 2),
        "Tax" => number_format($tax, 2),
        "Delivery Charges" => number_format($delivery_charges, 2),
        "Final Total" => number_format($final_total, 2),
        "shipping_address" => $shipping_data
    ];
} else {
    $response = ["status" => "error", "message" => "Invalid request"];
}

// Return JSON response
echo json_encode($response);
?>
