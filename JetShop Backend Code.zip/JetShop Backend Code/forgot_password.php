<?php
include 'config.php';
include 'send_mail.php';

header('Content-Type: application/json');

if (!isset($_POST['email'])) {
    echo json_encode(["status" => "error", "message" => "Missing email field"]);
    exit();
}

$email = trim($_POST['email']);
$otp = rand(100000, 999999); // Generate OTP

// ✅ Check if email exists
$stmt = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id, $name);

if ($stmt->fetch()) {
    // ✅ Update OTP in database
    $stmt->close();
    $stmt = $conn->prepare("UPDATE users SET otp = ? WHERE email = ?");
    $stmt->bind_param("ss", $otp, $email);
    if ($stmt->execute() && sendOTP($email, $name, $otp)) {
        echo json_encode(["status" => "success", "message" => "OTP sent to email."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to send OTP."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Email not found."]);
}
$stmt->close();
?>
