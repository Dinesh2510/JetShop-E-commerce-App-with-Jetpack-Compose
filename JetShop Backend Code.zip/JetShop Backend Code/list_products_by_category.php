<?php
header("Content-Type: application/json");
require_once "config.php"; // Database connection

if (!isset($_GET["category_id"]) || empty($_GET["category_id"])) {
    echo json_encode(["success" => false, "message" => "Category ID is required"]);
    exit;
}

$category_id = intval($_GET["category_id"]); // Convert to integer for safety

$sql = "SELECT * FROM products WHERE product_category_id = ? AND product_is_active = 1 ORDER BY product_created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $category_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    echo json_encode(["success" => true, "products" => $products]);
} else {
    echo json_encode(["success" => false, "message" => "No products found for this category"]);
}

$stmt->close();
$conn->close();
?>
