<?php
header("Content-Type: application/json");
require_once "config.php";  // Include database connection

// ✅ Check if cart_id is provided
if (!isset($_POST['cart_id']) || empty(trim($_POST['cart_id']))) {
    echo json_encode(["status" => "error", "message" => "Missing cart_id"]);
    exit();
}

$cart_id = trim($_POST['cart_id']);

// ✅ Delete query
$deleteQuery = "DELETE FROM cart WHERE cart_id = ?";
$stmt = $conn->prepare($deleteQuery);
$stmt->bind_param("s", $cart_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Cart item deleted successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Cart item not found"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Database error"]);
}

$stmt->close();
$conn->close();
?>
