<?php
include 'config.php';
header('Content-Type: application/json');

// ✅ 1. Get user_id from POST
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

if (!$user_id) {
    echo json_encode(["status" => "error", "message" => "Missing or invalid user ID"]);
    exit();
}

// ✅ 2. Get this user's referral code
$stmt = $conn->prepare("SELECT referral_code FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result->num_rows) {
    echo json_encode(["status" => "error", "message" => "User not found"]);
    exit();
}

$row = $result->fetch_assoc();
$referral_code = $row['referral_code'];

// ✅ 3. Get referral history with total bonus per referred user
$stmt = $conn->prepare("
    SELECT 
        u.id AS referred_user_id,
        u.first_name, 
        u.last_name, 
        u.email, 
        u.created_at,
        COALESCE(SUM(wt.amount), 0) AS bonus_earned
    FROM users u
    LEFT JOIN wallet_transactions wt 
        ON wt.user_id = u.id 
        AND wt.type = 'REFERRAL_BONUS'
        AND wt.description LIKE 'Referral bonus%'
    WHERE u.referred_by = ?
    GROUP BY u.id
");
$stmt->bind_param("s", $referral_code);
$stmt->execute();
$res = $stmt->get_result();

// ✅ 4. Format response
$referrals = [];
while ($r = $res->fetch_assoc()) {
    $referrals[] = [
        "name" => $r['first_name'] . ' ' . $r['last_name'],
        "email" => $r['email'],
        "joined_at" => date("Y-m-d", strtotime($r['created_at'])),
        "bonus_earned" => floatval($r['bonus_earned'])
    ];
}

// ✅ 5. Send JSON response
if (count($referrals) === 0) {
    echo json_encode([
        "status" => "error",
        "message" => "No referral history found."
    ]);
} else {
    echo json_encode([
        "status" => "success",
        "message" => "referral history found.",
        "total_referrals" => count($referrals),
        "referrals" => $referrals
    ]);
}

?>
