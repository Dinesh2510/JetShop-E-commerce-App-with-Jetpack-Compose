<?php
require_once "config.php";  // 
include 'header.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['order_id']) || empty(trim($_POST['order_id']))) {
        echo json_encode(["status" => "error", "message" => "Order ID is required"]);
        exit;
    }

    $order_id = trim($_POST['order_id']);

    // Fetch order details
    $query = "SELECT order_id, user_id, subtotal, discount_value, coupon_code, 
                     tax_amount, delivery_charges, total_amount, status, 
                     payment_status, payment_method, created_at 
              FROM orders WHERE order_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        echo json_encode(["status" => "error", "message" => "Order not found"]);
        exit;
    }

    $order = $result->fetch_assoc();

    // Fetch order items
$query_items = "SELECT oi.product_id, p.product_name, oi.quantity, oi.price, 
                        oi.tax, oi.total_price 
                 FROM order_items oi
                 JOIN products p ON CAST(oi.product_id AS CHAR) = CAST(p.product_id AS CHAR)
                 WHERE oi.order_id = ?";


    $stmt_items = $conn->prepare($query_items);
    $stmt_items->bind_param("s", $order_id);
    $stmt_items->execute();
    $result_items = $stmt_items->get_result();

    $order_items = [];
    while ($row = $result_items->fetch_assoc()) {
        $order_items[] = $row;
    }

    // Prepare response
    $response = [
        "status" => "success",
        "order_details" => $order,
        "order_items" => $order_items,
        "applied_coupon" => !empty($order['coupon_code']) ? $order['coupon_code'] : ""
    ];

    echo json_encode($response);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
