<?php
include 'config.php';
include 'header.php';

header('Content-Type: application/json');


// Fetch latest app info (assuming only 1 row)
$sql = "SELECT * FROM app_info ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $data = $result->fetch_assoc();

    // Format response
    echo json_encode([
        "status" => true,
        "data" => [
            "version_code" => (int)$data['version_code'],
            "version_name" => $data['version_name'],
            "is_maintenance_mode" => (bool)$data['is_maintenance_mode'],
            "maintenance_message" => $data['maintenance_message'],
            "is_update_required" => (bool)$data['is_update_required'],
            "update_message" => $data['update_message'],
            "promo_banner_url" => $data['promo_banner_url'],
            "promo_banner_link" => $data['promo_banner_link'],
            "app_currency" => $data['app_currency'],
            "razorpay_key" => $data['razorpay_key'],
            "support_email" => $data['support_email'],
            "contact_number" => $data['contact_number'],
            "app_language" => $data['app_language'],
            "show_login_popup" => (bool)$data['show_login_popup'],
            "home_notice_message" => $data['home_notice_message'],
            "faq_url" => $data['faq_url'],
            "terms_url" => $data['terms_url'],
            "privacy_url" => $data['privacy_url'],
        ]
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "No app info found"
    ]);
}

$conn->close();
