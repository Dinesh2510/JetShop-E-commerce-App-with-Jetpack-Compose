<?php
include 'config.php';
include 'header.php';

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $order_id = isset($_POST['order_id']) ? $_POST['order_id'] : '';

    if ($user_id <= 0 || empty($order_id)) {
        $response['success'] = false;
        $response['message'] = "Invalid user ID or order ID.";
        echo json_encode($response);
        exit;
    }

    // Step 1: Check if the order exists and belongs to the user
    $query = "SELECT status, payment_status FROM orders WHERE order_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "si", $order_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $order = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$order) {
        $response['success'] = false;
        $response['message'] = "Order not found or does not belong to the user.";
        echo json_encode($response);
        exit;
    }

    // Step 2: Check if the order is already cancelled or delivered
    if ($order['status'] === 'Cancelled') {
        $response['success'] = false;
        $response['message'] = "Order is already cancelled.";
        echo json_encode($response);
        exit;
    } elseif ($order['status'] === 'Delivered') {
        $response['success'] = false;
        $response['message'] = "Delivered orders cannot be cancelled.";
        echo json_encode($response);
        exit;
    }

    // Step 3: Update order status to "Cancelled"
    $updateOrderQuery = "UPDATE orders SET status = 'Cancelled', updated_at = NOW() WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $updateOrderQuery);
    mysqli_stmt_bind_param($stmt, "s", $order_id);
    $orderUpdated = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    if (!$orderUpdated) {
        $response['success'] = false;
        $response['message'] = "Failed to cancel the order. Please try again.";
        echo json_encode($response);
        exit;
    }

    // Step 4: If payment was made, update payment status (Optional)
    if ($order['payment_status'] === 'Paid') {
        $updatePaymentQuery = "UPDATE order_payments SET transaction_status = 'RefundPending' WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $updatePaymentQuery);
        mysqli_stmt_bind_param($stmt, "s", $order_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    // Step 5: Update order items and shipping (if necessary)
    $updateItemsQuery = "UPDATE order_items SET item_status = 'Cancelled' WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $updateItemsQuery);
    mysqli_stmt_bind_param($stmt, "s", $order_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $updateShippingQuery = "UPDATE order_shipping SET shipping_status = 'Cancelled' WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $updateShippingQuery);
    mysqli_stmt_bind_param($stmt, "s", $order_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Step 6: Return success response
    $response['success'] = true;
    $response['message'] = "Order has been cancelled successfully.";
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

echo json_encode($response);
?>
