<?php
include "headers.php";
include "config.php"; // Database connection

$response = ["status" => "error", "message" => "Invalid request"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $coupon_code = trim($_POST["coupon_code"]);

    if (empty($coupon_code)) {
        $response["message"] = "Coupon code is required";
    } else {
        $query = "UPDATE coupons SET used_count = used_count + 1 WHERE coupon_code = ? AND status = 'active' AND expiry_date >= CURDATE()";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $coupon_code);

        if ($stmt->execute()) {
            $response = ["status" => "success", "message" => "Coupon usage updated"];
        } else {
            $response["message"] = "Failed to update coupon usage";
        }
    }
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>
