<?php
include 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
function sendCartReminder($user_id, $fcm_token, $user_name, $items) {
    // Generate natural language message
    $itemList = implode(', ', array_slice($items, 0, 2)); // Show max 2 item names
    $more = count($items) > 2 ? ' and more' : '';
    
    $title = "Hey $user_name!";
    $message = "Still thinking about $itemList$more? Complete your purchase before it's gone!";
    
    // Optional: use emojis for fun touch
    $message .= " 🛒";

    // Send notification
    $data = [
        'notificationType' => 'cart_reminder',
        'title' => $title,
        'message' => $message,
        'imageUrl' => "https://yourdomain.com/assets/cart.png", // Optional
        'timestamp' => date("c")
    ];

    $notificationData = json_encode($data);
    $url = "https://pixeldev.in/webservices/jetshop/send_app_notification.php?fcm_token=" . urlencode($fcm_token) . "&data=" . urlencode($notificationData);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    echo "Notification sent to $user_name ($user_id): $message\n";
}

// Step 2: Fetch users with items in cart
$query = "SELECT u.id AS user_id, u.name, u.fcm, GROUP_CONCAT(p.name SEPARATOR ', ') as products
          FROM cart c 
          JOIN users u ON u.id = c.user_id 
          JOIN products p ON p.id = c.product_id
          GROUP BY u.id
          HAVING COUNT(*) > 0";

$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    $user_id = $row['user_id'];
    $user_name = $row['name'];
    $fcm_token = $row['fcm'];
    $products = explode(', ', $row['products']);

    if (!empty($fcm_token) && !empty($products)) {
        sendCartReminder($user_id, $fcm_token, $user_name, $products);
    }
}

echo "Cart-based reminders sent at " . date("Y-m-d H:i:s");
?>
