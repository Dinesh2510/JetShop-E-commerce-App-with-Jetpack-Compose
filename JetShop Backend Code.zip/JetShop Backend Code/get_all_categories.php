<?php
header("Content-Type: application/json");
require_once("config.php"); // Include your database connection file

$icon_base_url = "https://pixeldev.in/webservices/e_commerce/admin/";

// Fetch all active categories
$query = "SELECT id, name, CONCAT('$icon_base_url', icon) AS icon, draft, brief, priority, created_at 
          FROM productCategories 
          WHERE disable_flag = 0 
          ORDER BY priority ASC";

$result = mysqli_query($conn, $query);

$categories = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row;
    }
    echo json_encode(["status" => "success", "categories" => $categories]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to fetch categories"]);
}

mysqli_close($conn);
?>
