<?php
include 'send_mail.php';
$email = "dineshchavan2510@gmail.com"; // Replace with your email
$otp = rand(100000, 999999);
if (sendOTP($email,"Dinesh", $otp)) {
    echo "OTP Sent Successfully!";
} else {
    echo "Failed to Send OTP!";
}
?>
