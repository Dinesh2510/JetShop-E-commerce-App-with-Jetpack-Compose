<?php
include 'send_mail.php';
$email = "abcd@gmail.com"; // Replace with your email
$otp = rand(100000, 999999);
if (sendOTP($email,"Dinesh", $otp)) {
    echo "OTP Sent Successfully!";
} else {
    echo "Failed to Send OTP!";
}
?>
