<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function sendThankYouEmail($name, $email) {
    $mail = new PHPMailer(true);
    try {
         $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // ✅ Replace with your SMTP server (e.g., smtp.gmail.com)
        $mail->SMTPAuth = true;
        $mail->Username = 'pixeldevteams@gmail.com'; // ✅ Replace with your email
        $mail->Password = 'eeil kegu yvqq yjha'; // ✅ Replace with your email password or App Password
        $mail->SMTPSecure = 'tls'; // Use `ssl` if required by your provider
        $mail->Port = 587; // Change if using `ssl` (465)

        $mail->setFrom('support@pixeldev.in', 'JetShop'); // ✅ Replace with your email
        $mail->addAddress($email,$name); // ✅ Send OTP to user’s email
        
        $mail->isHTML(true);  // ✅ Enable HTML email
       $mail->Subject = '=?UTF-8?B?' . base64_encode('🎉 Welcome to JetShop! Your Account is Verified') . '?=';
       $mail->Subject = '=?UTF-8?B?' . base64_encode('🎉 Welcome to JetShop! Your Account is Verified') . '?=';
// Email Body
$mail->Body = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Welcome to JetShop</title>
    <style>
        /* Global Styles */
        * {
            box-sizing: border-box; /* Ensure padding and borders are included in the width and height */
        }

        body {
            font-family: 'Poppins', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
            width: 100%;
        }

        .email-container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding-right: 20px; /* Added padding to the right to ensure balance with left */
        }

        .header {
            text-align: center;
            padding: 20px 0;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }

        .header img {
            width: 120px;
        }

        .welcome-text {
            font-size: 18px;
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
            text-align: center;
        }

        .subtitle {
            font-size: 20px;
            font-weight: bold;
            color: #555;
            margin-bottom: 10px;
            text-align: center;
        }

        .description {
            font-size: 16px;
            color: #666;
            margin-bottom: 20px;
            text-align: center;
        }

        .cta-button {
            background-color: #04AA6D;
            color: #fff;
            padding: 15px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            max-width: 250px;
            margin: 0 auto;
            display: block;
        }

        .social-icons {
            margin-top: 20px;
            text-align: center;
        }

        .social-icons a {
            margin: 0 10px;
        }

        .social-icons img {
            width: 30px;
            height: 30px;
        }

        .footer {
            text-align: center;
            font-size: 14px;
            color: #999;
            margin-top: 20px;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }

        .footer a {
            color: #04AA6D;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <!-- Header -->
        <div class='header'>
            <img src='https://pixeldev.in/assets/img/logos.png' alt='JetShop Logo'>
        </div>

        <!-- Welcome Message -->
        <div class='welcome-text'>
            <p>Hi $name,</p>
            <p>Thanks for signing up! We're excited to have you on board and can't wait for you to explore amazing deals!</p>
        </div>

        <!-- Shopping Highlights -->
        <div class='title'>Start Shopping Now!</div>
        <div class='subtitle'>Amazing Deals & Exclusive Discounts</div>
        <div class='description'>
            Explore a wide range of products—fashion, gadgets, home goods, and much more! Enjoy personalized recommendations and exclusive offers just for you.
        </div>

        <!-- Call to Action Button -->
        <a href='https://pixeldev.in/jetshop' class='cta-button'>Open the App Now 🚀</a>

        <!-- Social Media Links -->
        <div class='social-icons'>
            <a href='https://pixeldev.in/' target='_blank'><img src='https://pixeldev.in/assets/img/logos.png' alt='Website'></a>
            <a href='https://github.com/Dinesh2510' target='_blank'><img src='https://github.githubassets.com/assets/GitHub-Mark-ea2971cee799.png' alt='GitHub'></a>
            <a href='https://www.instagram.com/pixel.designdeveloper/' target='_blank'><img src='https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png' alt='Instagram'></a>
            <a href='https://www.facebook.com/pixeldesigndeveloper' target='_blank'><img src='https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg' alt='Facebook'></a>
            <a href='https://www.youtube.com/@pixeldesigndeveloper' target='_blank'><img src='https://static.vecteezy.com/system/resources/thumbnails/023/986/480/small_2x/youtube-logo-youtube-logo-transparent-youtube-icon-transparent-free-free-png.png' alt='YouTube'></a>
        </div>

        <!-- Footer -->
        <div class='footer'>
            <p>If you need assistance, reach out to us at <a href='mailto:support@pixeldev.in'>support@pixeldev.in</a> or visit our <a href='https://pixeldev.in/faq'>FAQ</a>.</p>
            <p>&copy; 2025 JetShop. All rights reserved.</p>
            <p><a href='https://pixeldev.in/unsubscribe'>Unsubscribe</a> from our emails.</p>
        </div>
    </div>
</body>
</html>";



        $mail->send();
    } catch (Exception $e) {
        error_log("Email sending failed: " . $mail->ErrorInfo);
    }
}
?>
