<?php
include 'config.php';

header('Content-Type: application/json');

// Enable error reporting to see detailed error logs
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if required fields are set
if (!isset($_POST['user_id'], $_POST['address'], $_POST['city'], $_POST['state'], $_POST['zip_code'], $_POST['country'], $_POST['latitude'], $_POST['longitude'], $_POST['type'], $_POST['default_address'], $_POST['google_address'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$address = trim($_POST['address']);
$city = trim($_POST['city']);
$state = trim($_POST['state']);
$zip_code = trim($_POST['zip_code']);
$country = trim($_POST['country']);
$latitude = trim($_POST['latitude']);
$longitude = trim($_POST['longitude']);
$type = trim($_POST['type']);
$default_address = trim($_POST['default_address']);
$google_address = trim($_POST['google_address']); // New field for Google Address

// Ensure default_address is either 0 or 1
if ($default_address != '0' && $default_address != '1') {
    echo json_encode(["status" => "error", "message" => "Invalid default_address value. Use '0' or '1'."]);
    exit();
}

// Validate address type (Home or Office)
if (!in_array($type, ['Home', 'Office'])) {
    echo json_encode(["status" => "error", "message" => "Invalid address type. Use 'Home' or 'Office'."]);
    exit();
}

// If default address is set to 1, reset all other addresses for the user
if ($default_address == '1') {
    // Update all existing addresses for this user and set them to not default
    $update_sql = "UPDATE user_addresses SET default_address = 0 WHERE user_id = ? AND default_address = 1";
    $update_stmt = $conn->prepare($update_sql);

    if ($update_stmt === false) {
        echo json_encode(["status" => "error", "message" => "SQL prepare failed for update: " . $conn->error]);
        exit();
    }

    $update_stmt->bind_param("i", $user_id);
    if (!$update_stmt->execute()) {
        echo json_encode(["status" => "error", "message" => "Failed to reset default address. Error: " . $update_stmt->error]);
        exit();
    }
}

// Prepare SQL query for inserting new address with google_address field
$stmt = $conn->prepare("INSERT INTO user_addresses (user_id, address, city, state, zip_code, country, latitude, longitude, type, default_address, google_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmt === false) {
    // Output the error if the prepare fails
    echo json_encode(["status" => "error", "message" => "SQL prepare failed: " . $conn->error]);
    exit();
}

// Bind parameters for the new query (including google_address)
$stmt->bind_param("issssssdsds", $user_id, $address, $city, $state, $zip_code, $country, $latitude, $longitude, $type, $default_address, $google_address);

// Check if the execution is successful
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Address added successfully."]);
} else {
    // Output the error message if execution fails
    echo json_encode(["status" => "error", "message" => "Failed to add address. Error: " . $stmt->error]);
}

$stmt->close();
?>
