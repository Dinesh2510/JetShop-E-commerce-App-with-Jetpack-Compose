<?php
header("Content-Type: application/json");
require_once "config.php";  // Database connection

if (!isset($_POST['user_id'], $_POST['product_id'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$product_id = trim($_POST['product_id']);

// ✅ Check if the product is in the cart
$cartCheckQuery = "SELECT cart_id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
$cartCheckStmt = $conn->prepare($cartCheckQuery);
$cartCheckStmt->bind_param("ss", $user_id, $product_id);
$cartCheckStmt->execute();
$cartCheckStmt->store_result();
$cartCheckStmt->bind_result($cart_id, $current_quantity);

if ($cartCheckStmt->fetch()) {
    $cartCheckStmt->close();

    if ($current_quantity > 1) {
        // ✅ Decrease the quantity by 1
        $new_quantity = $current_quantity - 1;
        $updateCartQuery = "UPDATE cart SET quantity = ? WHERE cart_id = ?";
        $updateCartStmt = $conn->prepare($updateCartQuery);
        $updateCartStmt->bind_param("is", $new_quantity, $cart_id);

        if ($updateCartStmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Cart updated (quantity decreased by 1)"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to update cart"]);
        }
        $updateCartStmt->close();
    } else {
        // ✅ If quantity is 1, remove the product from cart
        $deleteCartQuery = "DELETE FROM cart WHERE cart_id = ?";
        $deleteCartStmt = $conn->prepare($deleteCartQuery);
        $deleteCartStmt->bind_param("s", $cart_id);

        if ($deleteCartStmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Product removed from cart"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to remove from cart"]);
        }
        $deleteCartStmt->close();
    }
} else {
    echo json_encode(["status" => "error", "message" => "Product not found in cart"]);
}

$conn->close();
?>
