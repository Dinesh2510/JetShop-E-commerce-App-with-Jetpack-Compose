<?php
include 'config.php';

header('Content-Type: application/json');

if (!isset($_POST['email'], $_POST['password'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$email = trim($_POST['email']);
$password = trim($_POST['password']);

// ✅ Check if email is registered
$stmt = $conn->prepare("SELECT id, password, is_verified FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id, $hashed_password, $is_verified);

if (!$stmt->fetch()) {
    echo json_encode(["status" => "error", "message" => "Email not registered."]);
    exit();
}
$stmt->close();

// ✅ Check if the account is verified
if ($is_verified == 0) {
    echo json_encode(["status" => "error", "message" => "Account not verified. Please verify your email."]);
    exit();
}

// ✅ Verify Password
if (password_verify($password, $hashed_password)) {
    echo json_encode([
        "status" => "success",
        "message" => "Login successful.",
        "user_id" => $id // ✅ Include user ID in the response
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid credentials."]);
}
?>
