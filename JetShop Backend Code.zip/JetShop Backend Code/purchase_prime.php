<?php
include 'config.php';
include 'header.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $amount = $_POST['amount'];
    $currency = $_POST['currency'];
    $transaction_id = $_POST['transaction_id'];
    $status = $_POST['status']; // 'SUCCESS' or 'FAILED'

    if ($status == 'SUCCESS') {
        $expiration_date = date('Y-m-d', strtotime('+1 year'));

        // Insert into prime_membership
       $query = "INSERT INTO prime_membership (user_id, amount_paid, currency, payment_method, transaction_id, transaction_status, start_date, expiry_date, created_at)
          VALUES ('$user_id', '$amount', '$currency', 'Online', '$transaction_id', 'PENDING', NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR), NOW())";

        mysqli_query($conn, $query);

        // Update user's Prime membership status
        // $updateQuery = "UPDATE users SET is_prime=1, prime_expiry='$expiration_date' WHERE user_id='$user_id'";
        // mysqli_query($conn, $updateQuery);

        $response['success'] = true;
        $response['message'] = "Prime membership activated!";
    } else {
        $response['success'] = false;
        $response['message'] = "Payment failed!";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

echo json_encode($response);
?>
