<?php
include 'config.php';
include 'header.php';
require 'PHPMailerAutoload.php'; // Make sure this file exists in the same directory

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch user_id and email from FormData
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    if ($user_id <= 0 || empty($email)) {
        $response['success'] = false;
        $response['message'] = "Invalid user ID or email.";
        echo json_encode($response);
        exit;
    }

    try {
        // Fetch Order Data
        $orderQuery = "SELECT order_id, user_id, subtotal, discount_value, coupon_code, tax_amount, delivery_charges, total_amount, status, payment_status, payment_method, transaction_status, created_at 
                       FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = mysqli_prepare($conn, $orderQuery);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $orderResult = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($orderResult) > 0) {
            $order = mysqli_fetch_assoc($orderResult);
            $order_id = $order['order_id'];

            // Fetch Order Items
            $itemsQuery = "SELECT oi.*, p.product_name, p.product_discount_price, p.product_image_url 
                           FROM order_items oi 
                           JOIN products p ON oi.product_id = p.product_id 
                           WHERE oi.order_id = ?";
            $stmt2 = mysqli_prepare($conn, $itemsQuery);
            mysqli_stmt_bind_param($stmt2, "s", $order_id);
            mysqli_stmt_execute($stmt2);
            $itemsResult = mysqli_stmt_get_result($stmt2);
            $items = mysqli_fetch_all($itemsResult, MYSQLI_ASSOC);
            mysqli_stmt_close($stmt2);

            // Fetch Shipping Details
            $shippingQuery = "SELECT * FROM order_shipping WHERE order_id = ?";
            $stmt3 = mysqli_prepare($conn, $shippingQuery);
            mysqli_stmt_bind_param($stmt3, "s", $order_id);
            mysqli_stmt_execute($stmt3);
            $shippingResult = mysqli_stmt_get_result($stmt3);
            $shipping = mysqli_fetch_assoc($shippingResult);
            mysqli_stmt_close($stmt3);

            // Fetch Payment Details
            $paymentQuery = "SELECT payment_method, amount, transaction_status FROM order_payments WHERE order_id = ?";
            $stmt4 = mysqli_prepare($conn, $paymentQuery);
            mysqli_stmt_bind_param($stmt4, "s", $order_id);
            mysqli_stmt_execute($stmt4);
            $paymentResult = mysqli_stmt_get_result($stmt4);
            $payment = mysqli_fetch_assoc($paymentResult);
            mysqli_stmt_close($stmt4);

            // Generate Email HTML
            function formatCurrency($amount) {
                return "$" . number_format((float)$amount, 2);
            }

            ob_start();
            include 'order_email_template.php'; // This file contains your email HTML template
            $emailHTML = ob_get_clean();

            // Send Email using PHPMailer
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Host = 'smtp.example.com'; // Replace with your SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = 'your_email@example.com'; // Replace with your email
            $mail->Password = 'your_email_password'; // Replace with your email password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('your_email@example.com', 'Your Store');
            $mail->addAddress($email);
            $mail->Subject = 'Your Order Confirmation - ' . $order_id;
            $mail->isHTML(true);
            $mail->Body = $emailHTML;

            if ($mail->send()) {
                $response['success'] = true;
                $response['message'] = "Order email sent successfully.";
            } else {
                $response['success'] = false;
                $response['message'] = "Failed to send email. Error: " . $mail->ErrorInfo;
            }
        } else {
            $response['success'] = false;
            $response['message'] = "No recent order found.";
        }

        mysqli_stmt_close($stmt);
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

echo json_encode($response);
?>
