<?php
require 'config.php'; // Include database connection

header('Content-Type: application/json');
$response = array();

if (!isset($_GET['brand_id'])) {
    $response['error'] = true;
    $response['message'] = "Missing required parameter: brand_id";
    echo json_encode($response);
    exit;
}

$brand_id = intval($_GET['brand_id']);

// Fetch all products for the given brand_id
$sql = "SELECT * FROM products WHERE product_brand_id = ? AND product_is_active = 1 ORDER BY product_id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $brand_id);
$stmt->execute();
$result = $stmt->get_result();

$products = array();
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

if (count($products) > 0) {
    $response['error'] = false;
    $response['products'] = $products;
} else {
    $response['error'] = true;
    $response['message'] = "No products found for this brand.";
}

echo json_encode($response);
?>
