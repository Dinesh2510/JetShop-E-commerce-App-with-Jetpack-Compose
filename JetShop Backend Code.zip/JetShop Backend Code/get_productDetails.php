<?php
header("Content-Type: application/json");
require_once "config.php";  // Database connection

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Initialize response array
$response = [];

// ✅ Check if product_id is provided via POST
if (!isset($_POST['product_id']) || empty(trim($_POST['product_id']))) {
    echo json_encode(["status" => "error", "message" => "Missing or empty product_id"]);
    exit();
}

$product_id = trim($_POST['product_id']);
$user_id = isset($_POST['user_id']) ? trim($_POST['user_id']) : null; // Check for user_id

// ✅ Check database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$conn->set_charset("utf8mb4"); // Ensure UTF-8 encoding for the database

// ✅ Query to fetch product details
$productQuery = "SELECT 
                    product_id, 
                    product_name, 
                    product_description, 
                    product_price, 
                    product_discount_price,
                    product_stock_quantity,
                    product_category_id,
                    product_brand_id,
                    product_weight,
                    product_dimensions,
                    product_color,
                    product_size,
                    product_rating,
                    product_total_reviews,
                    product_image_url,
                    product_thumbnail_url,
                    product_is_featured,
                    product_is_active,
                    product_created_at,
                    product_updated_at
                 FROM products 
                 WHERE product_id = ?";

$productStmt = $conn->prepare($productQuery);
$productStmt->bind_param("s", $product_id);
$productStmt->execute();
$productResult = $productStmt->get_result();

// ✅ Check if product exists
if ($productResult->num_rows > 0) {
    $productData = $productResult->fetch_assoc();
    $product_category_id = $productData['product_category_id']; // Store category ID for related products

    // ✅ Fetch reviews for the product and include user name
    $reviewQuery = "
    SELECT 
        reviews.review_id, 
        reviews.review_user_id, 
        reviews.review_rating, 
        reviews.review_title, 
        reviews.review_comment, 
        reviews.review_created_at, 
        CONCAT(users.first_name, ' ', users.last_name) AS user_name
    FROM reviews
    LEFT JOIN users ON reviews.review_user_id = users.id
    WHERE reviews.review_product_id = ?";

    $reviewStmt = $conn->prepare($reviewQuery);
    $reviewStmt->bind_param("s", $product_id);
    $reviewStmt->execute();
    $reviewResult = $reviewStmt->get_result();

    $reviews = [];
    if ($reviewResult->num_rows > 0) {
        while ($reviewRow = $reviewResult->fetch_assoc()) {
            $reviews[] = [
                "review_id" => $reviewRow['review_id'],
                "review_user_id" => $reviewRow['review_user_id'],
                "review_rating" => $reviewRow['review_rating'],
                "review_title" => $reviewRow['review_title'],
                "review_comment" => $reviewRow['review_comment'],
                "review_created_at" => $reviewRow['review_created_at'],
                "user_name" => $reviewRow['user_name']  // Add the user's name
            ];
        }
    }
    $reviewStmt->close();

    // ✅ Fetch review counts per rating range
    $reviewCountQuery = "
        SELECT 
            review_rating, 
            COUNT(*) as review_count 
        FROM reviews 
        WHERE review_product_id = ? 
        GROUP BY review_rating";
    
    $reviewCountStmt = $conn->prepare($reviewCountQuery);
    $reviewCountStmt->bind_param("s", $product_id);
    $reviewCountStmt->execute();
    $reviewCountResult = $reviewCountStmt->get_result();

    // Initialize counts for all possible rating ranges
    $reviewCounts = [
        "oneStarReviewCount" => 0,
        "twoStarReviewCount" => 0,
        "threeStarReviewCount" => 0,
        "fourStarReviewCount" => 0,
        "fiveStarReviewCount" => 0
    ];

    while ($row = $reviewCountResult->fetch_assoc()) {
        $rating = (float) $row['review_rating'];
        
        // Group ratings into ranges
        if ($rating >= 1.0 && $rating <= 1.9) {
            $reviewCounts["oneStarReviewCount"] += $row['review_count'];
        } elseif ($rating >= 2.0 && $rating <= 2.9) {
            $reviewCounts["twoStarReviewCount"] += $row['review_count'];
        } elseif ($rating >= 3.0 && $rating <= 3.9) {
            $reviewCounts["threeStarReviewCount"] += $row['review_count'];
        } elseif ($rating >= 4.0 && $rating <= 4.9) {
            $reviewCounts["fourStarReviewCount"] += $row['review_count'];
        } elseif ($rating >= 5.0 && $rating <= 5.0) { // Assuming max is 5
            $reviewCounts["fiveStarReviewCount"] += $row['review_count'];
        }
    }
    $reviewCountStmt->close();

    // ✅ Fetch related products (same category, excluding current product)
    $relatedProductQuery = "SELECT 
                                product_id, 
                                product_name, 
                                product_description, 
                                product_price, 
                                product_discount_price,
                                product_stock_quantity,
                                product_category_id,
                                product_brand_id,
                                product_weight,
                                product_dimensions,
                                product_color,
                                product_size,
                                product_rating,
                                product_total_reviews,
                                product_image_url,
                                product_thumbnail_url,
                                product_is_featured,
                                product_is_active,
                                product_created_at,
                                product_updated_at
                            FROM products 
                            WHERE product_category_id = ? 
                            AND product_id != ?";

    $relatedStmt = $conn->prepare($relatedProductQuery);
    $relatedStmt->bind_param("ss", $product_category_id, $product_id);
    $relatedStmt->execute();
    $relatedResult = $relatedStmt->get_result();

    $relatedProducts = [];
    if ($relatedResult->num_rows > 0) {
        while ($relatedRow = $relatedResult->fetch_assoc()) {
            $relatedProducts[] = $relatedRow;
        }
    }
    $relatedStmt->close();

    // ✅ Check if user_id is provided to fetch cart details
    $cartData = [];
    if ($user_id && !empty($user_id)) {
        // Check if the combination of user_id and product_id exists in the cart
        $cartQuery = "SELECT 
                        cart_id, 
                        user_id, 
                        product_id, 
                        quantity, 
                        added_at
                      FROM cart 
                      WHERE user_id = ? AND product_id = ?";

        $cartStmt = $conn->prepare($cartQuery);
        $cartStmt->bind_param("ss", $user_id, $product_id);
        $cartStmt->execute();
        $cartResult = $cartStmt->get_result();

        if ($cartResult->num_rows > 0) {
            // Fetch cart details if combination exists
            $cartData = $cartResult->fetch_assoc();
        }
        $cartStmt->close();
    }

    // ✅ Return response with product, reviews, review counts, related products, and cart details
    $response = [
        "status" => "success",
        "message" => "Product found successfully.",
        "product" => $productData,
        "reviewsData" => [
            "oneStarReviewCount" => $reviewCounts["oneStarReviewCount"],
            "twoStarReviewCount" => $reviewCounts["twoStarReviewCount"],
            "threeStarReviewCount" => $reviewCounts["threeStarReviewCount"],
            "fourStarReviewCount" => $reviewCounts["fourStarReviewCount"],
            "fiveStarReviewCount" => $reviewCounts["fiveStarReviewCount"],
            "totalReviewCount" => array_sum($reviewCounts),
            "reviewList" => $reviews // Include the reviews with user names
        ],
        //"related_products" => $relatedProducts,
    ];

    // Only add cartData if it exists
    if (!empty($cartData)) {
        $response["cartData"] = $cartData;
    }

    echo json_encode($response);

} else {
    echo json_encode(["status" => "error", "message" => "Product not found."]);
}

// ✅ Close statement and connection
$productStmt->close();
$conn->close();
?>
