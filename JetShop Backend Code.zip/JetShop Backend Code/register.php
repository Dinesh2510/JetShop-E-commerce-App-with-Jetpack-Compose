<?php
include 'config.php';
include 'send_mail.php';

header('Content-Type: application/json');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// ✅ Validate required fields
if (!isset($data['first_name'], $data['last_name'], $data['email'], $data['phone'], $data['password'])) {
    echo json_encode(["status" => "error", "flag" => "missing_fields", "message" => "Missing required fields"]);
    exit();
}

$first_name = trim($data['first_name']);
$last_name = trim($data['last_name']);
$email = trim($data['email']);
$phone = trim($data['phone']);
$password = password_hash(trim($data['password']), PASSWORD_BCRYPT);
$otp = rand(100000, 999999);
$otp_expiry = date("Y-m-d H:i:s", strtotime("+10 minutes"));
$referral_code = "JetShop_" . strtoupper(substr(md5(uniqid()), 0, 6));
$referred_by = isset($data['referred_by']) && !empty(trim($data['referred_by'])) ? trim($data['referred_by']) : null;

// ✅ Check if user already exists
$stmt = $conn->prepare("SELECT id, is_verified FROM users WHERE email = ? OR phone = ?");
$stmt->bind_param("ss", $email, $phone);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($existing_id, $is_verified);

if ($stmt->fetch()) {
    $stmt->close();

    if ($is_verified == 0) {
        // Resend OTP
        $stmt = $conn->prepare("UPDATE users SET otp = ?, otp_expiry = ? WHERE email = ?");
        $stmt->bind_param("sss", $otp, $otp_expiry, $email);

        if ($stmt->execute() && sendOTP($email, "$first_name $last_name", $otp)) {
            echo json_encode(["status" => "success", "flag" => "otp_resent", "message" => "OTP resent to email. Please verify."]);
        } else {
            echo json_encode(["status" => "error", "flag" => "otp_failed", "message" => "Failed to resend OTP. Try again."]);
        }
    } else {
        echo json_encode(["status" => "error", "flag" => "already_verified", "message" => "Email already registered."]);
    }
    exit();
}
$stmt->close();

// ✅ Begin transaction
$conn->begin_transaction();

try {
    // ✅ If referral code provided, validate it first
    if (!empty($referred_by)) {
        $stmt = $conn->prepare("SELECT id, wallet_balance FROM users WHERE referral_code = ?");
        $stmt->bind_param("s", $referred_by);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result->num_rows) {
            $conn->rollback();
            echo json_encode([
                "status" => "error",
                "flag" => "invalid_referral",
                "message" => "Invalid referral code. Please check and try again."
            ]);
            exit();
        }

        $referrer = $result->fetch_assoc();
        $referrer_id = $referrer['id'];
        $referrer_balance = $referrer['wallet_balance'];
    }

    // ✅ Insert user now (after referral is validated)
$stmt = $conn->prepare("INSERT INTO users 
    (first_name, last_name, email, phone, password, otp, otp_expiry, referral_code, referred_by, wallet_balance, is_verified) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)");
$stmt->bind_param("sssssssss", $first_name, $last_name, $email, $phone, $password, $otp, $otp_expiry, $referral_code, $referred_by);

    $stmt->execute();
    $new_user_id = $stmt->insert_id;

    // ✅ Apply referral bonus only if referral code is valid
    if (!empty($referred_by)) {
        $bonus = rand(10, 100);
        $referrer_bonus = $bonus;
        $new_user_bonus = $bonus;

        // 1. Update referrer wallet
        $new_ref_bal = $referrer_balance + $referrer_bonus;
        $stmt = $conn->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
        $stmt->bind_param("di", $new_ref_bal, $referrer_id);
        $stmt->execute();

        // 2. Insert referrer transaction
        $desc_ref = "Referral bonus from inviting $email";
        $stmt = $conn->prepare("INSERT INTO wallet_transactions 
            (user_id, referred_user_id, amount, type, description, balance_after_transaction, created_at, expiry_date) 
            VALUES (?, ?, ?, 'REFERRAL_BONUS', ?, ?, NOW(), NULL)");
        $stmt->bind_param("iidss", $referrer_id, $new_user_id, $referrer_bonus, $desc_ref, $new_ref_bal);
        $stmt->execute();

        // 3. Update new user wallet
        $stmt = $conn->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
        $stmt->bind_param("di", $new_user_bonus, $new_user_id);
        $stmt->execute();

        // 4. Insert new user transaction
        $desc_new = "Referral bonus for using code $referred_by";
        $stmt = $conn->prepare("INSERT INTO wallet_transactions 
            (user_id, referred_user_id, amount, type, description, balance_after_transaction, created_at, expiry_date) 
            VALUES (?, ?, ?, 'REFERRAL_BONUS', ?, ?, NOW(), NULL)");
        $stmt->bind_param("iidss", $new_user_id, $referrer_id, $new_user_bonus, $desc_new, $new_user_bonus);
        $stmt->execute();
    }

    // ✅ Commit everything
    $conn->commit();

    // ✅ Send OTP
    sendOTP($email, "$first_name $last_name", $otp);

    echo json_encode([
        "status" => "success",
        "flag" => "registered",
        "message" => "User registered. OTP sent to email."
    ]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        "status" => "error",
        "flag" => "registration_failed",
        "message" => "Registration failed. Please try again."
        // "debug" => $e->getMessage()
    ]);
}
?>
