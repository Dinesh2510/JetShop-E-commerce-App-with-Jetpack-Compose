<?php
ob_start(); // ✅ Start output buffering
header("Content-Type: application/json; charset=UTF-8");
require_once "config.php";  // ✅ Ensure this file has no extra output

// ✅ Enable Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Custom function to handle errors
function handleError($errno, $errstr, $errfile, $errline) {
    $errorData = [
        "status" => "error",
        "message" => "PHP Error: $errstr",
        "file" => $errfile,
        "line" => $errline
    ];
    echo json_encode($errorData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit();
}
set_error_handler("handleError"); // ✅ Catch errors

// ✅ Check if user_id is provided
if (!isset($_POST['user_id']) || empty(trim($_POST['user_id']))) {
    echo json_encode(["status" => "error", "message" => "Missing user_id"]);
    exit();
}

$user_id = trim($_POST['user_id']);

// ✅ Query to get cart items
$cartQuery = "
    SELECT 
        c.cart_id, c.quantity,
        p.product_id, p.product_name, p.product_description, 
        p.product_price, p.product_discount_price, p.product_stock_quantity, 
        p.product_category_id, p.product_brand_id, p.product_weight, 
        p.product_dimensions, p.product_color, p.product_size, 
        p.product_rating, p.product_total_reviews, p.product_image_url, 
        p.product_thumbnail_url, p.product_is_featured, p.product_is_active, 
        p.product_created_at, p.product_updated_at
    FROM cart c
    JOIN products p ON c.product_id = p.product_id
    WHERE c.user_id = ?";

$cartStmt = $conn->prepare($cartQuery);

// ✅ Check if statement is prepared successfully
if (!$cartStmt) {
    echo json_encode(["status" => "error", "message" => "SQL Prepare Error: " . $conn->error]);
    exit();
}

$cartStmt->bind_param("s", $user_id);
$cartStmt->execute();
$result = $cartStmt->get_result();

$cartItems = [];
$totalCartPrice = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // ✅ Safe UTF-8 conversion
        array_walk_recursive($row, function (&$value) {
            if (!mb_detect_encoding($value, 'UTF-8', true)) {
                $value = utf8_encode($value); // Convert only if encoding is unknown
            }
        });

        // Calculate item total price (considering discount if applicable)
        $itemPrice = isset($row['product_discount_price']) && !empty($row['product_discount_price']) ? $row['product_discount_price'] : $row['product_price'];
        $quantityAmountPrice = $itemPrice * $row['quantity']; // Total price for this product based on quantity

        // Add quantity-based price to total cart price
        $totalCartPrice += $quantityAmountPrice;

        // Add calculated price to each item in the cart data
        $row['quantity_amount_price'] = $quantityAmountPrice; // Add the total price for this item

        $cartItems[] = $row;
    }

    // Return response with cart items and total cart price
    echo json_encode([
        "status" => "success",
        "totalCartPrice" => number_format($totalCartPrice, 2), // Format the total cart price to 2 decimal places
         "cart_items" => $cartItems
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo json_encode(["status" => "error", "message" => "No items in cart"]);
}

// ✅ Close resources
$cartStmt->close();
$conn->close();
?>
