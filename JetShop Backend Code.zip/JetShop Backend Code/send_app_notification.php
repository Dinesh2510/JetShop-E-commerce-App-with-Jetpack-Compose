<?php

// Include configuration file
include 'config.php';
// Define Firebase Project and Service Account Info
define('FIREBASE_PROJECT_ID', 'firepdf-4c1d6'); // Replace with your Firebase Project ID
define('SERVICE_ACCOUNT_PATH', 'notification/service-account.json'); // Path to your service account JSON file inside the 'notification' folder

// Define API URLs
define('FCM_API_URL', 'https://fcm.googleapis.com/v1/projects/' . FIREBASE_PROJECT_ID . '/messages:send');
define('OAUTH2_TOKEN_URL', 'https://oauth2.googleapis.com/token');

// Handle CORS (if needed)
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Check request method
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$logs = []; // Initialize log messages

// Function to log messages
function logMessage($message, &$logs) {
    $timestamp = date('Y-m-d H:i:s');
    $logs[] = "[$timestamp] $message";
    file_put_contents('notification_log.txt', implode("\n", $logs), FILE_APPEND); // Optional log to file
}

logMessage("Data message request received.", $logs);

// Fetch data from query parameters
$fcmToken = isset($_GET['fcm_token']) ? $_GET['fcm_token'] : null;
$data = isset($_GET['data']) ? json_decode($_GET['data'], true) : null;

// Validate input data
if ($fcmToken === null || $data === null) {
    http_response_code(400);
    logMessage("Error: fcm_token or data is missing.", $logs);
    echo json_encode(['error' => 'fcm_token or data is missing', 'logs' => $logs]);
    exit;
}

// Fetch service account credentials
$serviceAccount = json_decode(file_get_contents(SERVICE_ACCOUNT_PATH), true);
if ($serviceAccount === null) {
    logMessage("Error: service-account.json is not valid JSON.", $logs);
    http_response_code(500);
    echo json_encode(['error' => 'Service account file error', 'logs' => $logs]);
    exit;
}

$clientEmail = $serviceAccount['client_email'];
$privateKey = $serviceAccount['private_key'];

// Generate the JWT for Firebase OAuth2 Token
$jwtHeader = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
$jwtPayload = base64_encode(json_encode([
    'iss' => $clientEmail,
    'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
    'aud' => 'https://oauth2.googleapis.com/token',
    'exp' => time() + 3600,
    'iat' => time()
]));
$jwtInput = $jwtHeader . '.' . $jwtPayload;

// Sign the JWT with the private key
openssl_sign($jwtInput, $signature, $privateKey, OPENSSL_ALGO_SHA256);
$jwtSignature = base64_encode($signature);
$jwt = $jwtInput . '.' . $jwtSignature;

// Fetch access token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, OAUTH2_TOKEN_URL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
    'assertion' => $jwt
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Handle errors in access token request
if (curl_errno($ch)) {
    logMessage("cURL error (access token): " . curl_error($ch), $logs);
    http_response_code(500);
    echo json_encode(['error' => 'cURL error (access token)', 'logs' => $logs]);
    exit;
}

$tokenResponse = json_decode($response, true);
if (isset($tokenResponse['error'])) {
    logMessage("Access token error: " . json_encode($tokenResponse), $logs);
    http_response_code(500);
    echo json_encode(['error' => 'Access token error', 'logs' => $logs]);
    exit;
}

$accessToken = $tokenResponse['access_token'];

// Send FCM data message
$message = [
    'message' => [
        'token' => $fcmToken,
        'data' => $data // Send custom data payload
    ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, FCM_API_URL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);

logMessage("FCM data message sent. Response: " . $result, $logs);

// Handle the response
$response = json_decode($result, true);
if (isset($response['error'])) {
    echo json_encode(['logs' => $logs, 'fcm_response' => $response]);
} else {
    echo json_encode(['logs' => $logs, 'fcm_response' => $response]);
}

?>
