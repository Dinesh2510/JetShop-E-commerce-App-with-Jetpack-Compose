<?php
include 'config.php';

header('Content-Type: application/json');

// Enable error reporting (for debugging/testing only)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the required fields are provided
if (!isset($_POST['user_id']) || (
    !isset($_POST['first_name']) &&
    !isset($_POST['last_name']) &&
    !isset($_POST['email']) &&
    !isset($_POST['phone']) &&
    (!isset($_FILES['profile_image']) || $_FILES['profile_image']['size'] == 0)
)) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : null;
$last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : null;
$email = isset($_POST['email']) ? trim($_POST['email']) : null;
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : null;
$profile_image = null;

// ✅ Check if user exists
$stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "User not found."]);
    exit();
}
$stmt->close();

// ✅ Handle Image Upload (Only if a file is provided and not empty)
if (
    isset($_FILES['profile_image']) &&
    $_FILES['profile_image']['error'] === UPLOAD_ERR_OK &&
    $_FILES['profile_image']['size'] > 0
) {
    $targetDir = "admin/user_profile/";

    // Create folder if not exist
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileTmpPath = $_FILES['profile_image']['tmp_name'];
    $fileName = basename($_FILES['profile_image']['name']);
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $newFileName = uniqid('profile_', true) . '.' . $fileExtension;
    $destination = $targetDir . $newFileName;

    if (move_uploaded_file($fileTmpPath, $destination)) {
        $profile_image = $destination;
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to upload image."]);
        exit();
    }
}

// ✅ Build dynamic update query
$query = "UPDATE users SET ";
$params = [];
$types = "";

if ($first_name !== null) {
    $query .= "first_name = ?, ";
    $params[] = $first_name;
    $types .= "s";
}
if ($last_name !== null) {
    $query .= "last_name = ?, ";
    $params[] = $last_name;
    $types .= "s";
}
if ($email !== null) {
    $query .= "email = ?, ";
    $params[] = $email;
    $types .= "s";
}
if ($phone !== null) {
    $query .= "phone = ?, ";
    $params[] = $phone;
    $types .= "s";
}
if ($profile_image !== null) {
    $query .= "profile_image = ?, ";
    $params[] = $profile_image;
    $types .= "s";
}

// Remove last comma and add WHERE clause
$query = rtrim($query, ", ") . " WHERE id = ?";
$params[] = $user_id;
$types .= "s";

// ✅ Execute the update query
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "SQL error: " . $conn->error]);
    exit();
}

$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "User details updated successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update user details."]);
}

$stmt->close();
?>
