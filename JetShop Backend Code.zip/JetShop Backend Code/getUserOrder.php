<?php
include 'config.php';
include 'header.php';

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch user_id from FormData
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

    if ($user_id <= 0) {
        $response['success'] = false;
        $response['message'] = "Invalid user ID.";
        echo json_encode($response);
        exit;
    }

    try {
        // **Step 1: Fetch Orders for the User**
        $orderQuery = "SELECT 
                            order_id, user_id, subtotal, discount_value, 
                            coupon_code, tax_amount, delivery_charges, 
                            total_amount, status, payment_status, 
                            payment_method, transaction_status, 
                            created_at, updated_at
                       FROM orders WHERE user_id = ? ORDER BY created_at DESC";
        $stmt = mysqli_prepare($conn, $orderQuery);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $orderResult = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($orderResult) > 0) {
            $orders = array();

            while ($orderRow = mysqli_fetch_assoc($orderResult)) {
                $order_id = $orderRow['order_id'];

                // **Step 2: Fetch Order Items with Product Details**
                $itemsQuery = "SELECT oi.*, 
                                      p.product_name, p.product_description, 
                                      p.product_price, p.product_discount_price, 
                                      p.product_stock_quantity, p.product_image_url 
                               FROM order_items oi 
                               JOIN products p ON oi.product_id = p.product_id 
                               WHERE oi.order_id = ?";
                $stmt2 = mysqli_prepare($conn, $itemsQuery);
                mysqli_stmt_bind_param($stmt2, "s", $order_id);
                mysqli_stmt_execute($stmt2);
                $itemsResult = mysqli_stmt_get_result($stmt2);
                $items = mysqli_fetch_all($itemsResult, MYSQLI_ASSOC);
                mysqli_stmt_close($stmt2);

                // **Step 3: Fetch Order Shipping Details**
                $shippingQuery = "SELECT * FROM order_shipping WHERE order_id = ?";
                $stmt3 = mysqli_prepare($conn, $shippingQuery);
                mysqli_stmt_bind_param($stmt3, "s", $order_id);
                mysqli_stmt_execute($stmt3);
                $shippingResult = mysqli_stmt_get_result($stmt3);
                $shippingDetails = mysqli_fetch_assoc($shippingResult);
                mysqli_stmt_close($stmt3);

                // **Step 4: Fetch Order Payment Details**
                $paymentQuery = "SELECT 
                                    payment_id, order_id, user_id, 
                                    payment_method, amount, currency, 
                                    transaction_id, transaction_status, 
                                    created_at, updated_at 
                                 FROM order_payments 
                                 WHERE order_id = ?";
                $stmt4 = mysqli_prepare($conn, $paymentQuery);
                mysqli_stmt_bind_param($stmt4, "s", $order_id);
                mysqli_stmt_execute($stmt4);
                $paymentResult = mysqli_stmt_get_result($stmt4);
                $paymentDetails = mysqli_fetch_assoc($paymentResult);
                mysqli_stmt_close($stmt4);

                // **Step 5: Structure Order Data**
                $createdAt = new DateTime($orderRow['created_at']);
                $createdAt->modify('+2 days')->setTime(21, 59, 59); // Set time to 9:59:59 PM
                $expectedDelivery = $createdAt->format('Y-m-d H:i:s');

                $orders[] = array(
                    'order_id' => $orderRow['order_id'],
                    'user_id' => $orderRow['user_id'],
                    'subtotal' => $orderRow['subtotal'],
                    'discount_value' => $orderRow['discount_value'],
                    'coupon_code' => $orderRow['coupon_code'],
                    'tax_amount' => $orderRow['tax_amount'],
                    'delivery_charges' => $orderRow['delivery_charges'],
                    'total_amount' => $orderRow['total_amount'],
                    'status' => $orderRow['status'],
                    'payment_status' => $orderRow['payment_status'],
                    'payment_method' => $orderRow['payment_method'],
                    'transaction_status' => $orderRow['transaction_status'],
                    'created_at' => $orderRow['created_at'],
                    'updated_at' => $orderRow['updated_at'],
                    'expected_delivery_date' => $expectedDelivery, // ✅ New field added
                    'items' => $items,
                    'shipping_details' => $shippingDetails ? $shippingDetails : null,
                    'payment_details' => $paymentDetails ? $paymentDetails : null
                );

            }

            $response['success'] = true;
            $response['message'] = "Orders retrieved successfully.";
            $response['orders'] = $orders;
        } else {
            $response['success'] = false;
            $response['message'] = "No orders found for this user.";
        }

        mysqli_stmt_close($stmt);
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

echo json_encode($response);
?>
