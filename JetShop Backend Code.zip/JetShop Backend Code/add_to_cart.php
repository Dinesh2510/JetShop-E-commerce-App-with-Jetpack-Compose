<?php
header("Content-Type: application/json");
require_once "config.php";  // Database connection

if (!isset($_POST['user_id'], $_POST['product_id'], $_POST['quantity'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$product_id = trim($_POST['product_id']);
$quantity = intval($_POST['quantity']);

if ($quantity <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid quantity"]);
    exit();
}

// ✅ Check if product exists and has enough stock
$productQuery = "SELECT product_stock_quantity FROM products WHERE product_id = ?";
$productStmt = $conn->prepare($productQuery);
$productStmt->bind_param("s", $product_id);
$productStmt->execute();
$productStmt->store_result();
$productStmt->bind_result($available_stock);

if (!$productStmt->fetch()) {
    echo json_encode(["status" => "error", "message" => "Product not found"]);
    exit();
}
$productStmt->close();

// ✅ Check if stock is available
if ($available_stock < $quantity) {
    echo json_encode(["status" => "error", "message" => "Not enough stock available"]);
    exit();
}

// ✅ Check if the product is already in the cart
$cartCheckQuery = "SELECT cart_id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
$cartCheckStmt = $conn->prepare($cartCheckQuery);
$cartCheckStmt->bind_param("ss", $user_id, $product_id);
$cartCheckStmt->execute();
$cartCheckStmt->store_result();

if ($cartCheckStmt->num_rows > 0) {
    // ✅ Update existing cart item
    $cartCheckStmt->bind_result($cart_id, $existing_quantity);
    $cartCheckStmt->fetch();
    $cartCheckStmt->close();

    $new_quantity = $existing_quantity + $quantity;
    if ($new_quantity > $available_stock) {
        echo json_encode(["status" => "error", "message" => "Not enough stock available"]);
        exit();
    }

    $updateCartQuery = "UPDATE cart SET quantity = ?, added_at = CURRENT_TIMESTAMP WHERE cart_id = ?";
    $updateCartStmt = $conn->prepare($updateCartQuery);
    $updateCartStmt->bind_param("is", $new_quantity, $cart_id);

    if ($updateCartStmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Cart updated"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update cart"]);
    }
    $updateCartStmt->close();
} else {
    // ✅ Insert new cart item
    $cartCheckStmt->close();
    $cart_id = uniqid("CART");

    $insertCartQuery = "INSERT INTO cart (cart_id, user_id, product_id, quantity) VALUES (?, ?, ?, ?)";
    $insertCartStmt = $conn->prepare($insertCartQuery);
    $insertCartStmt->bind_param("sssi", $cart_id, $user_id, $product_id, $quantity);

    if ($insertCartStmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Added to cart"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add to cart"]);
    }
    $insertCartStmt->close();
}

$conn->close();
?>
