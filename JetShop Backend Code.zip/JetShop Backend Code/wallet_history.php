<?php
include 'config.php'; // your DB connection

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'] ?? '';

    if (empty($user_id)) {
        $response['status'] = 'error';
        $response['message'] = 'User ID is required';
    } else {
        $query = "SELECT * FROM wallet_transactions WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $transactions = [];
        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }

        $response['status'] = 'success';
        $response['message'] = 'Wallet history fetched successfully';
        $response['transactions'] = $transactions;
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

echo json_encode($response);
?>
