<?php
include 'config.php';  // Include the database configuration
include 'header.php';  // Include header if necessary (optional)

header('Content-Type: application/json');

// ✅ Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(["status" => "error", "message" => "Invalid request method. Use GET method."]);
    exit();
}

// ✅ Fetch blogs from the database
$query = "SELECT blog_id, title, subtitle, description, image_url, published_date, view_count FROM blogs ORDER BY published_date DESC";

// Use MySQLi to prepare and execute the query
$stmt = $conn->prepare($query);
$stmt->execute();

// ✅ Fetch all blogs as an associative array
$blogs = [];
$result = $stmt->get_result();  // Get the result set
while ($row = $result->fetch_assoc()) {
    $blogs[] = $row;  // Add each row to the $blogs array
}

// ✅ Check if there are any blogs
if (empty($blogs)) {
    echo json_encode(["status" => "error", "message" => "No blogs found."]);
    exit();
}

// ✅ Return blogs as JSON
echo json_encode(["status" => "success", "message" => "Blogs fetched successfully.", "data" => $blogs]);
?>
