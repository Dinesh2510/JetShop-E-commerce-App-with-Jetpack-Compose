<?php
include 'config.php';

header('Content-Type: application/json');

if (!isset($_POST['user_id'], $_POST['fcm_token'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$fcm_token = trim($_POST['fcm_token']);

// Check if user exists
$userCheckQuery = $conn->prepare("SELECT id FROM users WHERE id = ?");
$userCheckQuery->bind_param("i", $user_id);
$userCheckQuery->execute();
$userCheckQuery->store_result();

if ($userCheckQuery->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "User not found"]);
    exit();
}

$userCheckQuery->close();

// Update FCM token
$updateQuery = $conn->prepare("UPDATE users SET fcm = ? WHERE id = ?");
$updateQuery->bind_param("si", $fcm_token, $user_id);

if ($updateQuery->execute()) {
    echo json_encode(["status" => "success", "message" => "FCM token updated successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update FCM token"]);
}

$updateQuery->close();
$conn->close();
?>
