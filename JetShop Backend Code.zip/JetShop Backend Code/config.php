<?php
header('Content-Type: application/json; charset=utf-8');

$servername = "localhost"; // Change if needed
$username = ""; // Change to your database user
$password = ""; // Change to your database password
$dbname = ""; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Set UTF-8 Encoding for proper Unicode support
$conn->set_charset("utf8mb4");

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}

// Function to execute queries safely
function executeQuery($conn, $sql) {
    $result = $conn->query($sql);
    if (!$result) {
        die(json_encode(["status" => "error", "message" => "SQL Error: " . $conn->error]));
    }
    return $result;
}
?>
