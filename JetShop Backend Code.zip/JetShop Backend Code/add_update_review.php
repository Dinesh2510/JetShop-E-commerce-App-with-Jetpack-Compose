<?php
header("Content-Type: application/json");
require_once "config.php";  // Database connection

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ✅ Check if required fields are provided
if (!isset($_POST['user_id'], $_POST['product_id'], $_POST['rating'], $_POST['title'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$product_id = trim($_POST['product_id']);
$rating = trim($_POST['rating']);
$title = trim($_POST['title']);
$comment = isset($_POST['comment']) ? trim($_POST['comment']) : null;

// ✅ Validate rating (should be between 1.0 - 5.0)
if ($rating < 1.0 || $rating > 5.0) {
    echo json_encode(["status" => "error", "message" => "Invalid rating value. It must be between 1.0 and 5.0"]);
    exit();
}

// ✅ Check if the user has already reviewed this product
$checkQuery = "SELECT review_id FROM reviews WHERE review_product_id = ? AND review_user_id = ?";
$checkStmt = $conn->prepare($checkQuery);
if ($checkStmt === false) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement for checking review."]);
    exit();
}

$checkStmt->bind_param("ss", $product_id, $user_id);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    // ✅ Update existing review
    $checkStmt->bind_result($review_id);
    $checkStmt->fetch();
    $checkStmt->close();

    $updateQuery = "UPDATE reviews SET review_rating = ?, review_title = ?, review_comment = ?, review_created_at = CURRENT_TIMESTAMP WHERE review_id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    if ($updateStmt === false) {
        echo json_encode(["status" => "error", "message" => "Failed to prepare update statement."]);
        exit();
    }
    $updateStmt->bind_param("dsss", $rating, $title, $comment, $review_id);

    if ($updateStmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Review updated successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update review."]);
    }
    $updateStmt->close();
} else {
    // ✅ Insert new review
    $checkStmt->close();
    $review_id = uniqid("REV"); // Unique Review ID

    $insertQuery = "INSERT INTO reviews (review_id, review_product_id, review_user_id, review_rating, review_title, review_comment) VALUES (?, ?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertQuery);
    if ($insertStmt === false) {
        echo json_encode(["status" => "error", "message" => "Failed to prepare insert statement."]);
        exit();
    }
    $insertStmt->bind_param("sssdss", $review_id, $product_id, $user_id, $rating, $title, $comment);

    if ($insertStmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Review added successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add review."]);
    }
    $insertStmt->close();
}

// ✅ Close database connection
$conn->close();
?>
