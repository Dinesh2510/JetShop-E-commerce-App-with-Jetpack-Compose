<?php
include 'config.php';
include 'header.php';
include 'email_template.php'; // Include email template file

$response = array();
$logs = [];

function addLog($message) {
    global $logs;
    $timestamp = date("Y-m-d H:i:s");
    $logs[] = "$timestamp - $message";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = isset($_POST['order_id']) ? trim($_POST['order_id']) : '';
    $transaction_id = isset($_POST['transaction_id']) ? trim($_POST['transaction_id']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';
    $gateway_response = isset($_POST['gateway_response']) ? trim($_POST['gateway_response']) : '';
    $user_id = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';

    if (empty($order_id) || empty($transaction_id) || empty($status) || empty($gateway_response) || empty($user_id)) {
        echo json_encode(["status" => "error", "message" => "Missing required fields.", "logs" => $logs]);
        exit;
    }

    try {
        // Update order_payments table
        $query = "UPDATE order_payments 
                  SET transaction_id = ?, transaction_status = ?, gateway_response = ?, updated_at = NOW() 
                  WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "ssss", $transaction_id, $status, $gateway_response, $order_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Update orders table
        $payment_status = ($status == 'SUCCESS') ? 'PAID' : 'FAILED';
        $updateOrderQuery = "UPDATE orders SET payment_status = ?, transaction_status = ? WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $updateOrderQuery);
        mysqli_stmt_bind_param($stmt, "sss", $payment_status, $status, $order_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Fetch user details for email
        $userQuery = "SELECT email, name FROM users WHERE id = ?";
        $stmt = mysqli_prepare($conn, $userQuery);
        mysqli_stmt_bind_param($stmt, "s", $user_id);
        mysqli_stmt_execute($stmt);
        $userResult = mysqli_stmt_get_result($stmt);
        $userData = mysqli_fetch_assoc($userResult);
        mysqli_stmt_close($stmt);

        $email = $userData['email'];
        $name = $userData['name'];

        if ($status == 'SUCCESS') {
            // Delete cart items
            $deleteCartQuery = "DELETE FROM cart WHERE user_id = ?";
            $stmt = mysqli_prepare($conn, $deleteCartQuery);
            mysqli_stmt_bind_param($stmt, "s", $user_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            // Send order confirmation email
            sendOrderEmail($email, $name, $order_id, 'Order Successful', 'Your order has been confirmed.', 'success');
        } else {
            // Send payment failure email
            sendOrderEmail($email, $name, $order_id, 'Payment Failed', 'Your payment attempt failed. Please try again.', 'failed');
        }

        echo json_encode([ 
            "status" => "success", 
            "message" => "Payment verified successfully", 
            "payment_status" => $payment_status,
            "logs" => $logs
        ]);
    } catch (Exception $e) {
        echo json_encode([ 
            "status" => "error", 
            "message" => $e->getMessage(), 
            "payment_status" => "FAILED", 
            "logs" => $logs 
        ]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method", "logs" => $logs]);
}
header('Content-Type: application/json');
