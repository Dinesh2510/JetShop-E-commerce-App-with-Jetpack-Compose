<?php
include 'config.php';

header('Content-Type: application/json');

// Get input parameters
$order_id = $_POST['order_id'] ?? '';

if (empty($order_id)) {
    echo json_encode(["success" => false, "message" => "Order ID is required."]);
    exit;
}

// Get applied coupon code from order
$order_query = $conn->prepare("SELECT coupon_code, subtotal, tax_amount, delivery_charges FROM orders WHERE order_id = ?");
$order_query->bind_param("s", $order_id);
$order_query->execute();
$order_result = $order_query->get_result();
$order = $order_result->fetch_assoc();

if (!$order || empty($order['coupon_code'])) {
    echo json_encode(["success" => false, "message" => "No applied coupon found."]);
    exit;
}

$coupon_code = $order['coupon_code'];

// Decrease coupon usage count (Ensure it doesn’t go below zero)
$update_coupon = $conn->prepare("UPDATE coupons SET used_count = GREATEST(used_count - 1, 0) WHERE coupon_code = ?");
$update_coupon->bind_param("s", $coupon_code);
$update_coupon->execute();

// Remove coupon from order (reset discount and recalculate total)
$total_amount = $order['subtotal'] + $order['tax_amount'] + $order['delivery_charges'];

$reset_order = $conn->prepare("UPDATE orders SET coupon_code = NULL, discount_value = 0, total_amount = ? WHERE order_id = ?");
$reset_order->bind_param("ds", $total_amount, $order_id);
$reset_order->execute();

echo json_encode(["success" => true, "message" => "Coupon removed successfully.", "new_total" => $total_amount]);
?>
