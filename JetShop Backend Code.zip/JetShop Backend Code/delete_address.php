<?php
// Include your database connection file
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get user input
    $user_id = $_POST['user_id'];
    $address_id = $_POST['address_id'];

    // Validate input
    if (empty($user_id) || empty($address_id)) {
        echo json_encode(array("status" => "error", "message" => "User ID and Address ID are required."));
        exit();
    }

    // Check if the user exists
    $checkUser = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($checkUser);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        echo json_encode(array("status" => "error", "message" => "User not found."));
        exit();
    }

    // Check if the address exists for the given user
    $checkAddress = "SELECT * FROM user_addresses WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($checkAddress);
    $stmt->bind_param("ii", $address_id, $user_id);
    $stmt->execute();
    $addressResult = $stmt->get_result();

    if ($addressResult->num_rows == 0) {
        echo json_encode(array("status" => "error", "message" => "Address not found for this user."));
        exit();
    }

    // Delete the address
    $deleteAddress = "DELETE FROM user_addresses WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($deleteAddress);
    $stmt->bind_param("ii", $address_id, $user_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(array("status" => "sucess", "message" => "Address deleted successfully."));
    } else {
        echo json_encode(array("status" => "error", "message" => "Failed to delete address."));
    }
}
?>
