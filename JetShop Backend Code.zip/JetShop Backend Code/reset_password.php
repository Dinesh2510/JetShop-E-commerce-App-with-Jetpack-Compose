<?php
include 'config.php';

header('Content-Type: application/json');

if (!isset($_POST['email'], $_POST['otp'], $_POST['new_password'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$email = trim($_POST['email']);
$otp = trim($_POST['otp']);
$new_password = password_hash(trim($_POST['new_password']), PASSWORD_BCRYPT);

// ✅ Check if email is registered
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "Email not registered."]);
    exit();
}
$stmt->close();

// ✅ Verify OTP
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND otp = ?");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    // ✅ OTP is correct, update password
    $stmt->close();
    $stmt = $conn->prepare("UPDATE users SET password = ?, otp = NULL WHERE email = ?");
    $stmt->bind_param("ss", $new_password, $email);
    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Password reset successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to reset password."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid OTP."]);
}
$stmt->close();
?>
