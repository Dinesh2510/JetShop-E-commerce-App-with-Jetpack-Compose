<?php
include 'config.php'; // Your DB config

// List of 50 promotional messages
$messages = [
    "🔥 Big Sale on Electronics!", "🎁 Surprise Discount Just for You!",
    "🛒 Extra 10% Off on Your Next Order", "📦 Free Shipping This Week!",
    "🎉 Festival Sale Starts Now!", "💥 Flat 50% Off!", "🧧 Exclusive Deals Inside!",
    "🤑 Save More with Coupon SAVE20", "🎈 Clearance Sale – Hurry!",
    "💫 Top Picks for You!", "🌟 Today’s Hot Deal!", "🎯 Prices Dropped!",
    "🎀 Special Offer Ends Tonight", "📣 Grab the Deal Now!", "🛍️ Flash Sale Live!",
    "⏰ Limited Time Offer", "🎇 Shopping Fest is ON!", "🏷️ Mega Discount Awaits!",
    "🎪 Deals You Can't Miss!", "🧨 Blast Prices!", "🥳 Birthday Special Offers!",
    "🎂 Treat Yourself Today!", "💼 Office Essentials at Low Prices",
    "👚 Fashion Deals Inside", "👟 Sportswear Sale!", "🧴 Skincare Steals",
    "🍕 Food Discounts!", "🏠 Home Decor Deals", "🖥️ Laptop Discounts",
    "📱 Phone Deals Just Dropped", "🎧 Audio Gear Offers", "🧸 Toy Sale!",
    "📚 Back to School Offers", "🎮 Gamer’s Paradise Sale", "🌈 Colorful Deals Await",
    "📍 Trending Picks", "👗 Style Up Your Wardrobe", "💄 Beauty Deals Inside",
    "👜 Bag It Before It's Gone", "🔋 Power Deals", "🚿 Bathroom Essentials",
    "🧹 Clean Up Sale!", "🪑 Furniture Offers", "🧳 Travel Smart, Save More",
    "📦 Stock Up & Save", "💻 Tech Weekend", "🎤 Music Lovers Discount",
    "🐾 Pet Products Sale", "🕒 Time-Limited Mystery Deal", "🛎️ Your Deal is Waiting"
];

// Select a random title
$title = $messages[array_rand($messages)];
$message = "Tap to explore exclusive discounts now!";

// Fetch all users who have FCM tokens
$query = "SELECT id, fcm FROM users WHERE fcm IS NOT NULL AND fcm != ''";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    $user_id = $row['id'];
    $fcm_token = $row['fcm'];

    $data = [
        'notificationType' => 'promotion',
        'title' => $title,
        'message' => $message,
        'imageUrl' => 'https://pixeldev.in/assets/img/logos.png',
        'customLog' => 'Scheduled Promotion',
        'timestamp' => date("c")
    ];

    $notificationData = json_encode($data);

    $url = "https://pixeldev.in/webservices/jetshop/send_app_notification.php?fcm_token=" . urlencode($fcm_token) . "&data=" . urlencode($notificationData);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}

echo "Promotional notifications sent at " . date("Y-m-d H:i:s");
?>
