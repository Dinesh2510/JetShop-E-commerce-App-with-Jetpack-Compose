<?php
include 'config.php';

header('Content-Type: application/json');

if (!isset($_POST['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Missing user_id"]);
    exit();
}

$user_id = trim($_POST['user_id']);

$stmt = $conn->prepare("SELECT id, address, default_address, google_address,city, state, zip_code, country, latitude, longitude, type FROM user_addresses WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$addresses = [];
while ($row = $result->fetch_assoc()) {
    $addresses[] = $row;
}

if (count($addresses) > 0) {
    echo json_encode(["status" => "success", "addresses" => $addresses]);
} else {
    echo json_encode(["status" => "error", "message" => "No addresses found."]);
}
$stmt->close();
?>
