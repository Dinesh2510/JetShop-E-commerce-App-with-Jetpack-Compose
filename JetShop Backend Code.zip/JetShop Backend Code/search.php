<?php
include 'config.php'; // Include the database configuration
include 'header.php'; // Include the header for API response

// Set character set to UTF-8 for database connection (to handle special characters correctly)
$conn->set_charset("utf8mb4");

// Capture the GET parameters (with defaults)
$product_name = isset($_GET['product_name']) ? $_GET['product_name'] : '';
$rating = isset($_GET['rating']) ? $_GET['rating'] : ''; // Rating (e.g., 1 to 5)

// Base SQL query - Search both product_name and product_description for the search term
$sql = "SELECT * FROM products WHERE product_name LIKE '%$product_name%' OR product_description LIKE '%$product_name%'";

// Apply Rating Filter (if rating is provided)
if ($rating !== '') {
    // Ensure the rating is a number between 1 and 5
    if (is_numeric($rating) && $rating >= 1 && $rating <= 5) {
        $sql .= " AND (product_rating IS NULL OR product_rating >= '$rating')";
    } else {
        // If invalid rating is passed, return an error
        echo json_encode(['status' => 'error', 'message' => 'Invalid rating value']);
        exit;
    }
}

// Debugging: Print the SQL query
// echo "Executing Query: " . $sql . "<br>"; // Uncomment for debugging

// Execute the query
$result = $conn->query($sql);

// Check for query error
if (!$result) {
    echo "Error executing query: " . $conn->error;
    exit;
}

// Check if data exists
if ($result->num_rows > 0) {
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row; // Store the product data in an array
    }

    // Return the product list as JSON
    echo json_encode(['status' => 'success', 'data' => $products]);
} else {
    // If no products are found, return an empty response
    echo json_encode(['status' => 'error', 'message' => 'No products found']);
}

$conn->close(); // Close the database connection
?>
