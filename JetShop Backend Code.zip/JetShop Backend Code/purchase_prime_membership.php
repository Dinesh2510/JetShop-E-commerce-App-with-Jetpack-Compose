<?php
include 'config.php';
include 'header.php';

$data = json_decode(file_get_contents("php://input"));

if (
    isset($data->user_id) && isset($data->plan_name) && isset($data->plan_price) &&
    isset($data->amount_paid) && isset($data->payment_method) &&
    isset($data->transaction_id) && isset($data->transaction_status)
) {
    $user_id = $conn->real_escape_string($data->user_id);
    $plan_name = $conn->real_escape_string($data->plan_name);
    $plan_price = $conn->real_escape_string($data->plan_price);
    $amount_paid = $conn->real_escape_string($data->amount_paid);
    $payment_method = $conn->real_escape_string($data->payment_method);
    $transaction_id = $conn->real_escape_string($data->transaction_id);
    $transaction_status = $conn->real_escape_string($data->transaction_status);
//payment_gateway_response
    // Calculate dates based on plan
    $start_date = date('Y-m-d H:i:s');
    if (strtolower($plan_name) === 'prime') {
        $expiry_date = date('Y-m-d H:i:s', strtotime("+1 year"));
    } else if (strtolower($plan_name) === 'primelite') {
        $expiry_date = date('Y-m-d H:i:s', strtotime("+6 months"));
    } else {
        echo json_encode(["success" => false, "message" => "Invalid plan name."]);
        exit;
    }

    // Check for existing active membership
    $check = $conn->query("SELECT * FROM prime_membership WHERE user_id = '$user_id' AND expiry_date > NOW()");
    if ($check->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "User already has an active membership."]);
        exit;
    }

    $sql = "INSERT INTO prime_membership (
                user_id, plan_name, plan_price, amount_paid, currency,
                payment_method, transaction_id, transaction_status, start_date, expiry_date
            ) VALUES (
                '$user_id', '$plan_name', '$plan_price', '$amount_paid', 'INR',
                '$payment_method', '$transaction_id', '$transaction_status', '$start_date', '$expiry_date'
            )";

    if ($conn->query($sql)) {
        echo json_encode(["success" => true, "message" => "Prime membership activated."]);
    } else {
        echo json_encode(["success" => false, "message" => "Database error: " . $conn->error]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Missing required fields."]);
}
?>
