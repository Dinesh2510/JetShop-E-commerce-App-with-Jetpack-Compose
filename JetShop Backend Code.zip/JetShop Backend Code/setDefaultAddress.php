<?php
include 'config.php';

header('Content-Type: application/json');

// Enable error reporting to see detailed error logs
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if required fields are set in FormData
if (!isset($_POST['user_id'], $_POST['address_id'])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$user_id = trim($_POST['user_id']);
$address_id = trim($_POST['address_id']);
$default_address = 1;  // Default address is always 1 as per your requirement

// Reset all addresses to non-default for the user
$update_sql = "UPDATE user_addresses SET default_address = 0 WHERE user_id = ? AND default_address = 1";
$update_stmt = $conn->prepare($update_sql);

if ($update_stmt === false) {
    echo json_encode(["status" => "error", "message" => "SQL prepare failed for update: " . $conn->error]);
    exit();
}

$update_stmt->bind_param("i", $user_id);
if (!$update_stmt->execute()) {
    echo json_encode(["status" => "error", "message" => "Failed to reset default address. Error: " . $update_stmt->error]);
    exit();
}

// Set the selected address as the default
$update_default_sql = "UPDATE user_addresses SET default_address = ? WHERE user_id = ? AND id = ?";
$update_default_stmt = $conn->prepare($update_default_sql);

if ($update_default_stmt === false) {
    echo json_encode(["status" => "error", "message" => "SQL prepare failed for setting default: " . $conn->error]);
    exit();
}

$update_default_stmt->bind_param("iii", $default_address, $user_id, $address_id);

if ($update_default_stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Address default status updated successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update default address. Error: " . $update_default_stmt->error]);
}

$update_stmt->close();
$update_default_stmt->close();
?>
