<?php
include 'config.php';
header('Content-Type: application/json');

if (!isset($_POST['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Missing user_id"]);
    exit();
}

$user_id = trim($_POST['user_id']);

// ✅ Fetch user details including profile_image
$stmt = $conn->prepare("SELECT id, first_name, last_name, email, phone, profile_image, referral_code, referred_by, wallet_balance FROM users WHERE id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id, $first_name, $last_name, $email, $phone, $profile_image, $referral_code, $referred_by, $wallet_balance);


if ($stmt->fetch()) {
    $stmt->close();

    // ✅ Fetch prime membership details
    $prime_stmt = $conn->prepare("SELECT id, user_id, plan_name, plan_price, amount_paid, currency, payment_method, transaction_id, transaction_status, payment_gateway_response, start_date, expiry_date, created_at FROM prime_membership WHERE user_id = ?");
    $prime_stmt->bind_param("s", $user_id);
    $prime_stmt->execute();
    $prime_result = $prime_stmt->get_result();

    $prime_details = null;
    $isPrimeActive = 0;

    if ($row = $prime_result->fetch_assoc()) {
        $current_date = date('Y-m-d');
        $expiry_date = $row['expiry_date'];

        if ($expiry_date >= $current_date) {
            $isPrimeActive = 1;
        }

        $prime_details = [
            "id" => $row['id'],
            "user_id" => $row['user_id'],
            "plan_name" => $row['plan_name'],
            "plan_price" => $row['plan_price'],
            "amount_paid" => $row['amount_paid'],
            "currency" => $row['currency'],
            "payment_method" => $row['payment_method'],
            "transaction_id" => $row['transaction_id'],
            "transaction_status" => $row['transaction_status'],
            "payment_gateway_response" => $row['payment_gateway_response'],
            "start_date" => $row['start_date'],
            "expiry_date" => $row['expiry_date'],
            "created_at" => $row['created_at']
        ];
    }

    $prime_stmt->close();

    echo json_encode([
        "status" => "success",
       "user" => [
    "user_id" => $id,
    "first_name" => $first_name,
    "last_name" => $last_name,
    "name" => $first_name . ' ' . $last_name,
    "email" => $email,
    "phone" => $phone,
    "profile_image" => $profile_image,
    "referral_code" => $referral_code,
    "referred_by" => $referred_by,
    "wallet_balance" => floatval($wallet_balance),
    "isPrimeActive" => $isPrimeActive,
    "prime_membership" => $prime_details
]

    ]);
} else {
    echo json_encode(["status" => "error", "message" => "User not found"]);
    $stmt->close();
}
?>
