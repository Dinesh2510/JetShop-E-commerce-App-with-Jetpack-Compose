<?php
// send_notification.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header("Content-Type: application/json");

// CORS Headers for frontend access (if needed)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle OPTIONS preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$logs = []; // Array to store log messages

function logMessage($message, &$logs) {
    $timestamp = date('Y-m-d H:i:s');
    $logs[] = "[$timestamp] $message";
}

logMessage("Data message request received.", $logs);

// Get data from the URL query parameters
$fcmToken = isset($_GET['fcm_token']) ? $_GET['fcm_token'] : null;
$data = isset($_GET['data']) ? json_decode($_GET['data'], true) : null;

if ($fcmToken === null || $data === null) {
    http_response_code(400); // Bad Request
    logMessage("Error: fcm_token or data is missing.", $logs);
    echo json_encode(['error' => 'fcm_token or data is missing', 'logs' => $logs]);
    exit;
}

// FCM v1 HTTP API configuration
$projectId = 'firepdf-4c1d6'; // Replace with your Firebase Project ID
$serviceAccountPath = 'service-account.json'; // Path to your service account JSON file
$serviceAccount = json_decode(file_get_contents($serviceAccountPath), true);

if ($serviceAccount === null) {
    logMessage("Error: service-account.json is not valid JSON.", $logs);
    http_response_code(500);
    echo json_encode(['error' => 'Service account file error', 'logs' => $logs]);
    exit;
}

$clientEmail = $serviceAccount['client_email'];
$privateKey = $serviceAccount['private_key'];

// Generate access token
$jwtHeader = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
$jwtPayload = base64_encode(json_encode([
    'iss' => $clientEmail,
    'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
    'aud' => 'https://oauth2.googleapis.com/token',
    'exp' => time() + 3600,
    'iat' => time()
]));
$jwtInput = $jwtHeader . '.' . $jwtPayload;

if (!function_exists('openssl_sign')) {
    logMessage("Error: openssl_sign function not available.", $logs);
    http_response_code(500);
    echo json_encode(['error' => 'OpenSSL extension not enabled', 'logs' => $logs]);
    exit;
}

openssl_sign($jwtInput, $signature, $privateKey, OPENSSL_ALGO_SHA256);
$jwtSignature = base64_encode($signature);
$jwt = $jwtInput . '.' . $jwtSignature;

// Access Token request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
    'assertion' => $jwt
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);

if (curl_errno($ch)) {
    logMessage("cURL error (access token): " . curl_error($ch), $logs);
    http_response_code(500);
    echo json_encode(['error' => 'cURL error (access token)', 'logs' => $logs]);
    curl_close($ch);
    exit;
}

curl_close($ch);

$tokenResponse = json_decode($response, true);
if (isset($tokenResponse['error'])) {
    logMessage("Access token error: " . json_encode($tokenResponse), $logs);
    http_response_code(500);
    echo json_encode(['error' => 'Access token error', 'logs' => $logs]);
    exit;
}

$accessToken = $tokenResponse['access_token'];

// Send FCM data message
$message = [
    'message' => [
        'token' => $fcmToken,
        'data' => $data
    ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);

if (curl_errno($ch)) {
    logMessage("cURL error (FCM data message): " . curl_error($ch), $logs);
    http_response_code(500);
    echo json_encode(['error' => 'cURL error (FCM data message)', 'logs' => $logs]);
    curl_close($ch);
    exit;
}

curl_close($ch);

logMessage("FCM data message sent. Response: " . $result, $logs);

$response = json_decode($result, true);

if (isset($response['error'])) {
    echo json_encode(['logs' => $logs, 'fcm_response' => $response]);
} else {
    echo json_encode(['logs' => $logs, 'fcm_response' => json_decode($result, true)]);
}
?>
