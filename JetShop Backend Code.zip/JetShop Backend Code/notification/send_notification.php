<?php
// FCM HTTP v1 API URL
define('FCM_SERVER_URL', 'https://fcm.googleapis.com/v1/projects/firepdf-4c1d6/messages:send');

// Path to your Firebase service account JSON key file
define('SERVICE_ACCOUNT_KEY_FILE', __DIR__ . '/service-account.json');

// Function to get an OAuth 2.0 token
function getAccessToken() {
    $keyFileContent = file_get_contents(SERVICE_ACCOUNT_KEY_FILE);
    $serviceAccount = json_decode($keyFileContent, true);

    // Create a JWT (JSON Web Token)
    $header = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    $claimSet = base64_encode(json_encode([
        'iss' => $serviceAccount['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => 'https://oauth2.googleapis.com/token',
        'exp' => time() + 3600,
        'iat' => time()
    ]));

    $unsignedToken = $header . '.' . $claimSet;

    // Sign the JWT with the private key
    $privateKey = $serviceAccount['private_key'];
    $signature = '';
    openssl_sign($unsignedToken, $signature, $privateKey, 'SHA256');
    $signedToken = $unsignedToken . '.' . base64_encode($signature);

    // Use the JWT to get an access token from Google
    $response = json_decode(file_get_contents('https://oauth2.googleapis.com/token', false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query([
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $signedToken
            ])
        ]
    ])), true);

    return $response['access_token'] ?? null;
}

// Function to send a Data Message
function sendDataMessage($deviceToken, $title, $body, $imageUrl = null) {
    $accessToken = getAccessToken();
    if (!$accessToken) {
        die('Failed to obtain access token.');
    }

    // Data Message payload (NO "notification" key)
    $message = [
        'message' => [
            'token' => $deviceToken,
            'data' => [
                'title' => $title,
                'body' => $body,
                'imageUrl' => $imageUrl ?? '',
                'extraData' => 'Any additional data you need'
            ]
        ]
    ];

    // HTTP headers
    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json'
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, FCM_SERVER_URL);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));

    // Execute cURL request
    $result = curl_exec($ch);

    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
    }

    // Close cURL and return result
    curl_close($ch);
    return $result;
}

// Usage example (POST data from admin panel)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $deviceToken = $_POST['deviceToken']; // FCM device token from Android app
    $title = $_POST['title'];            // Notification title
    $body = $_POST['body'];              // Notification body
    $imageUrl = $_POST['imageUrl'] ?? null; // Optional: Notification image URL

    if (!empty($deviceToken) && !empty($title) && !empty($body)) {
        $response = sendDataMessage($deviceToken, $title, $body, $imageUrl);
        echo "Response from FCM: " . $response;
    } else {
        echo "Error: Missing required parameters (deviceToken, title, or body).";
    }
} else {
    echo "Invalid request method. Use POST.";
}
