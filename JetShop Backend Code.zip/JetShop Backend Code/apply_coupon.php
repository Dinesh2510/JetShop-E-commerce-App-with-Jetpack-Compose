<?php
include 'config.php';  // Database connection
header('Content-Type: application/json');

$order_id = $_POST['order_id'] ?? '';
$coupon_code = $_POST['coupon_code'] ?? '';

// Debug: Check incoming data
if (empty($order_id) || empty($coupon_code)) {
    die(json_encode(["status" => "error", "message" => "Order ID and Coupon Code are required"]));
}

// Fetch order details
$order_query = $conn->prepare("SELECT subtotal, discount_value, coupon_code, total_amount FROM orders WHERE order_id = ?");
$order_query->bind_param("s", $order_id);
$order_query->execute();
$order_result = $order_query->get_result();

if ($order_result->num_rows == 0) {
    die(json_encode(["status" => "error", "message" => "Invalid order ID"]));
}

$order_data = $order_result->fetch_assoc();

// Debug: Print Order Details
error_log(print_r($order_data, true));

// Ensure no coupon is already applied
if (!empty($order_data['coupon_code'])) {
    die(json_encode(["status" => "error", "message" => "A coupon is already applied to this order"]));
}

// Fetch coupon details
$coupon_query = $conn->prepare("SELECT * FROM coupons WHERE coupon_code = ? AND status = 'Active' AND expiry_date >= CURDATE()");
$coupon_query->bind_param("s", $coupon_code);
$coupon_query->execute();
$coupon_result = $coupon_query->get_result();

if ($coupon_result->num_rows == 0) {
    die(json_encode(["status" => "error", "message" => "Invalid or expired coupon"]));
}

$coupon = $coupon_result->fetch_assoc();

// Debug: Print Coupon Details
error_log(print_r($coupon, true));

// Check if usage limit is reached
if ($coupon['used_count'] >= $coupon['usage_limit']) {
    die(json_encode(["status" => "error", "message" => "Coupon usage limit reached"]));
}

// Check minimum order amount condition
if ($order_data['subtotal'] < $coupon['min_order_amount']) {
    die(json_encode(["status" => "error", "message" => "Order total is less than the required minimum"]));
}

// Calculate discount
// Calculate discount
$discount = 0;
if ($coupon['discount_type'] == 'fixed') {
    $discount = $coupon['discount_value']; // Directly apply the fixed discount
} else { // percentage-based
    $discount = min(($order_data['subtotal'] * ($coupon['discount_value'] / 100)), $coupon['max_discount']);
}


// Ensure discount does not exceed subtotal
$discount = min($discount, $order_data['subtotal']);

// Debug: Print Discount Calculation
error_log("Discount Calculated: " . $discount);

// Calculate new total
$new_total = $order_data['total_amount'] - $discount;

// Debug: Print Updated Total Amount
error_log("New Total Amount: " . $new_total);

// Apply coupon to order
$update_order = $conn->prepare("UPDATE orders SET discount_value = ?, coupon_code = ?, total_amount = ? WHERE order_id = ?");
$update_order->bind_param("dssd", $discount, $coupon_code, $new_total, $order_id);

if ($update_order->execute()) {
    // Increment coupon usage count
    $update_coupon_usage = $conn->prepare("UPDATE coupons SET used_count = used_count + 1 WHERE coupon_code = ?");
    $update_coupon_usage->bind_param("s", $coupon_code);
    $update_coupon_usage->execute();

    echo json_encode([
        "status" => "success",
        "message" => "Coupon applied successfully",
        "discount" => $discount,
        "new_total" => $new_total
    ]);
} else {
    die(json_encode(["status" => "error", "message" => "Failed to apply coupon"]));
}
?>
