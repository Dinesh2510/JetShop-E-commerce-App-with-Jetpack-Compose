<?php
include "headers.php";
include "config.php";


$response = ["status" => "error", "message" => "Something went wrong"];

$query = "SELECT * FROM coupons WHERE status = 'active' AND expiry_date >= CURDATE()";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $coupons = [];
    while ($row = $result->fetch_assoc()) {
        $coupons[] = $row;
    }
    $response = ["status" => "success", "message" => "Coupons fetched successfully", "data" => $coupons];
} else {
    $response = ["status" => "error", "message" => "No active coupons found"];
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>
