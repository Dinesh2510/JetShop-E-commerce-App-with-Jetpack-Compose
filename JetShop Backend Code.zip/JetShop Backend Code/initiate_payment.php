<?php
include 'config.php';
include 'header.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = isset($_POST['order_id']) ? trim($_POST['order_id']) : '';
    $user_id = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';
    $payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';
    $amount = isset($_POST['amount']) ? trim($_POST['amount']) : '';
    $currency = isset($_POST['currency']) ? trim($_POST['currency']) : '';

    if (empty($order_id) || empty($user_id) || empty($payment_method) || empty($amount) || empty($currency)) {
        $response['success'] = false;
        $response['message'] = "Error: Missing required fields.";
        echo json_encode($response);
        exit;
    }

    try {
        // Check if order_id exists
        $orderCheckQuery = "SELECT order_id FROM orders WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $orderCheckQuery);
        if (!$stmt) throw new Exception("Error in query: " . mysqli_error($conn));
        mysqli_stmt_bind_param($stmt, "s", $order_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) == 0) {
            throw new Exception("Error: Invalid order ID.");
        }
        mysqli_stmt_close($stmt);

        // Check if payment already exists
        $checkQuery = "SELECT COUNT(*) as count FROM order_payments WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $checkQuery);
        if (!$stmt) throw new Exception("Error in query: " . mysqli_error($conn));
        mysqli_stmt_bind_param($stmt, "s", $order_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($row['count'] > 0) {
            throw new Exception("Error: Payment already initiated for this order.");
        }

        if ($payment_method == "COD") {
            // COD Logic
            $updateOrderQuery = "UPDATE orders SET payment_method = ?, payment_status = 'COD_CONFIRMED' WHERE order_id = ?";
            $stmt = mysqli_prepare($conn, $updateOrderQuery);
            if (!$stmt) throw new Exception("Error in query: " . mysqli_error($conn));
            mysqli_stmt_bind_param($stmt, "ss", $payment_method, $order_id);
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Failed to update order for COD: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt);

            // Clear cart
            $deleteCartQuery = "DELETE FROM cart WHERE user_id = ?";
            $stmt2 = mysqli_prepare($conn, $deleteCartQuery);
            if (!$stmt2) throw new Exception("Error in query: " . mysqli_error($conn));
            mysqli_stmt_bind_param($stmt2, "i", $user_id);
            if (!mysqli_stmt_execute($stmt2)) {
                throw new Exception("Failed to clear cart: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt2);

            // ✅ Send notification for COD success
            sendNotification($user_id, 'Order Confirmed', 'Your order has been successfully placed with Cash on Delivery.', 'order_update', 'COD Order Placed');

            $response['success'] = true;
            $response['message'] = "Order placed successfully with Cash on Delivery.";
            $response['payment_status'] = "COD_CONFIRMED";
        } else {
            // Online Payment Flow
            $query = "INSERT INTO order_payments (order_id, user_id, payment_method, amount, currency, transaction_status, created_at) 
                      VALUES (?, ?, ?, ?, ?, 'PENDING', NOW())";
            $stmt = mysqli_prepare($conn, $query);
            if (!$stmt) throw new Exception("Error in query: " . mysqli_error($conn));
            mysqli_stmt_bind_param($stmt, "sssss", $order_id, $user_id, $payment_method, $amount, $currency);
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Failed to initiate payment: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt);

            $updateQuery = "UPDATE orders SET payment_method = ?, payment_status = 'PENDING' WHERE order_id = ?";
            $stmt = mysqli_prepare($conn, $updateQuery);
            if (!$stmt) throw new Exception("Error in query: " . mysqli_error($conn));
            mysqli_stmt_bind_param($stmt, "ss", $payment_method, $order_id);
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Failed to update order payment method: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt);

            $response['success'] = true;
            $response['message'] = "Payment initiated successfully!";
            $response['payment_status'] = "PENDING";
        }
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = $e->getMessage();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

header('Content-Type: application/json');
echo json_encode($response);

/**
 * Function to send a notification to a user
 */
function sendNotification($user_id, $title, $message, $notificationType, $customLog) {
    global $conn;

    $query = "SELECT fcm FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) throw new Exception("Error in query: " . mysqli_error($conn));

    mysqli_stmt_bind_param($stmt, "s", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $fcm_token = $row['fcm'];
        $data = [
            'notificationType' => $notificationType,
            'title' => $title,
            'message' => $message,
            'imageUrl' => "https://pixeldev.in/assets/img/logos.png",
            'customLog' => $customLog,
            'timestamp' => date("c")
        ];
        $notificationData = json_encode($data);
        $url = "https://pixeldev.in/webservices/jetshop/send_app_notification.php?fcm_token=" . urlencode($fcm_token) . "&data=" . urlencode($notificationData);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    } else {
        throw new Exception("FCM Token not found for user_id: " . $user_id);
    }

    mysqli_stmt_close($stmt);
}
?>
