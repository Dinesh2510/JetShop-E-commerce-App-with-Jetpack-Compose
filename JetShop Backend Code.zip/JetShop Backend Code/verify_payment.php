<?php
include 'config.php';
include 'header.php';

$response = array();
$logs = []; // Array to hold log messages

// Function to add logs to the logs array
function addLog($message) {
    global $logs;
    $timestamp = date("Y-m-d H:i:s");
    $logs[] = "$timestamp - $message"; // Add log message with timestamp
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = isset($_POST['order_id']) ? trim($_POST['order_id']) : '';
    $transaction_id = isset($_POST['transaction_id']) ? trim($_POST['transaction_id']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : ''; // 'SUCCESS' or 'FAILED'
    $gateway_response = isset($_POST['gateway_response']) ? trim($_POST['gateway_response']) : '';
    $user_id = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';
    $plan_name = isset($_POST['planName']) ? trim($_POST['planName']) : '';
    $plan_price = isset($_POST['planPrice']) ? trim($_POST['planPrice']) : '';
    
    // Check if all required parameters are provided
    if (empty($order_id) || empty($transaction_id) || empty($status) || empty($gateway_response) || empty($user_id)) {
       // addLog("Missing required fields for order ID: $order_id, user ID: $user_id.");
        echo json_encode(["status" => "error", "message" => "Missing required fields.", "logs" => $logs]);
        exit;
    }

    try {
        // **Step 1: Update order_payments table**
        $query = "UPDATE order_payments 
                  SET transaction_id = ?, transaction_status = ?, gateway_response = ?, updated_at = NOW() 
                  WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $query);
        if (!$stmt) {
          //  addLog("Error in query: " . mysqli_error($conn));
            throw new Exception("Error in query: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "ssss", $transaction_id, $status, $gateway_response, $order_id);
        if (!mysqli_stmt_execute($stmt)) {
        //    addLog("Failed to update payment status for order_id: $order_id.");
            throw new Exception("Failed to update payment status: " . mysqli_error($conn));
        }
        mysqli_stmt_close($stmt);

       // addLog("Payment status updated successfully for order_id: $order_id.");

        // **Step 2: Update orders table**
        $payment_status = ($status == 'SUCCESS') ? 'PAID' : 'FAILED';
        $updateOrderQuery = "UPDATE orders SET payment_status = ?, transaction_status = ? WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $updateOrderQuery);
        if (!$stmt) {
         //   addLog("Error in query: " . mysqli_error($conn));
            throw new Exception("Error in query: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "sss", $payment_status, $status, $order_id);
        if (!mysqli_stmt_execute($stmt)) {
       //     addLog("Failed to update order payment status for order_id: $order_id.");
            throw new Exception("Failed to update order payment status: " . mysqli_error($conn));
        }
        mysqli_stmt_close($stmt);

     //   addLog("Order payment status updated successfully for order_id: $order_id.");

// **Step 3: If payment is successful, handle membership, delete cart, send notification**
if ($status == 'SUCCESS') {

    // Step 3.1: Handle Prime Membership if applicable
    if (!empty($plan_name) && !empty($plan_price) && $plan_price != "0") {
        $plan_name_lower = strtolower($plan_name);
        $start_date = date('Y-m-d H:i:s');

        if ($plan_name_lower === 'prime') {
            $expiry_date = date('Y-m-d H:i:s', strtotime("+1 year"));
        } else if ($plan_name_lower === 'primelite') {
            $expiry_date = date('Y-m-d H:i:s', strtotime("+6 months"));
        } else {
            addLog("Invalid plan name '$plan_name'. Skipping membership insertion.");
        }

        if (isset($expiry_date)) {
            $check_query = "SELECT * FROM prime_membership WHERE user_id = ? AND expiry_date > NOW()";
            $stmt_check = mysqli_prepare($conn, $check_query);
            mysqli_stmt_bind_param($stmt_check, "s", $user_id);
            mysqli_stmt_execute($stmt_check);
            $result_check = mysqli_stmt_get_result($stmt_check);

            if (mysqli_num_rows($result_check) > 0) {
                addLog("User $user_id already has an active membership. Skipping insert.");
            } else {
                $insert_query = "INSERT INTO prime_membership (
                    user_id, plan_name, plan_price, amount_paid, currency,
                    payment_method, transaction_id, transaction_status, start_date, expiry_date
                ) VALUES (?, ?, ?, ?, 'INR', ?, ?, ?, ?, ?)";

                // TODO: Replace 'your_payment_method' with actual value if available
                $payment_method = 'your_payment_method'; // <== adjust accordingly
                $stmt_insert = mysqli_prepare($conn, $insert_query);
                mysqli_stmt_bind_param($stmt_insert, "sssssssss",
                    $user_id, $plan_name, $plan_price, $plan_price,
                    $payment_method, $transaction_id, $status, $start_date, $expiry_date);

                if (mysqli_stmt_execute($stmt_insert)) {
                    addLog("Prime membership inserted successfully for user_id: $user_id.");
                } else {
                    addLog("Failed to insert membership for user_id: $user_id. Error: " . mysqli_error($conn));
                }

                mysqli_stmt_close($stmt_insert);
            }

            mysqli_stmt_close($stmt_check);
        }
    }

    // Step 3.2: Delete Cart Items
    $deleteCartQuery = "DELETE FROM cart WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $deleteCartQuery);
    if (!$stmt) {
        throw new Exception("Error in query: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "s", $user_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to clear cart: " . mysqli_error($conn));
    }
    mysqli_stmt_close($stmt);

    // Step 4: Send Notification
    sendNotification($user_id, 'Order Successful', 'Your payment was successful and your order is confirmed.', 'order_update', 'Promotion campaign March 2025');
}


        // If payment status is FAILED, return an error with relevant details
        if ($status == 'FAILED') {
            // **Step 4: Send Failure Notification with Data Payload**
          //  addLog("Sending FAILURE notification to user_id: $user_id.");
            sendNotification($user_id, 'Payment Failed', 'Your payment attempt failed. Please try again.', 'order_update', 'Failed payment attempt March 2025');
            
           // addLog("Payment failed for order_id: $order_id.");
            echo json_encode([ 
                "status" => "error", 
                "message" => "Payment failed. Please try again.", 
                "payment_status" => "FAILED",
                "logs" => $logs
            ]);
            exit;
        }

      //  addLog("Payment verified successfully for order_id: $order_id.");
        echo json_encode([ 
            "status" => "success", 
            "message" => "Payment verified successfully", 
            "payment_status" => $payment_status, 
            "logs" => $logs
        ]);

    } catch (Exception $e) {
      ////  addLog("Error: " . $e->getMessage());
        echo json_encode([ 
            "status" => "error", 
            "message" => $e->getMessage(), 
            "payment_status" => "FAILED", 
            "logs" => $logs 
        ]);
    }
} else {
   // addLog("Invalid request method.");
    echo json_encode(["status" => "error", "message" => "Invalid request method", "logs" => $logs]);
}

header('Content-Type: application/json');

/**
 * Function to send a notification to a user
 * 
 * @param string $user_id - The user ID to fetch FCM token
 * @param string $title - The notification title
 * @param string $message - The notification message
 * @param string $notificationType - Type of notification (order, promotion, etc.)
 * @param string $customLog - Custom description for logging
 */
function sendNotification($user_id, $title, $message, $notificationType, $customLog) {
    global $conn, $logs;
    
    // Query to get the user's FCM token from the database (adjust based on your user table)
    $query = "SELECT fcm FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
       // addLog("Error in query: " . mysqli_error($conn));
        throw new Exception("Error in query: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "s", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        $fcm_token = $row['fcm'];
        
        // Prepare the notification data with your custom structure
        $data = [
            'notificationType' => $notificationType,
            'title' => $title,
            'message' => $message,
            'imageUrl' => "https://pixeldev.in/assets/img/logos.png",  // You can change the image URL as per requirement
            'customLog' => $customLog,
            'timestamp' => date("c") // Using current timestamp in ISO 8601 format
        ];
        
        // Prepare the data to be passed to the notification function
        $notificationData = json_encode($data);

        // Call the send_notification.php script via a URL or trigger its function here
        // Assuming you have a function to handle the send notification process, or call the notification script via CURL
        $url = "https://pixeldev.in/webservices/jetshop/send_app_notification.php?fcm_token=" . urlencode($fcm_token) . "&data=" . urlencode($notificationData);
        
        // Use CURL to send the request
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

      //  addLog("Notification sent to fcm_token: $fcm_token");
    } else {
       // addLog("FCM Token not found for user_id: " . $user_id);
        throw new Exception("FCM Token not found for user_id: " . $user_id);
    }

    mysqli_stmt_close($stmt);
}
?>
